package com.noxring.ui;
import com.noxring.LodConfig; import com.noxring.LodManager;
import net.minecraft.client.gui.screen.Screen; import net.minecraft.client.gui.widget.ButtonWidget; import net.minecraft.client.gui.widget.SliderWidget; import net.minecraft.text.Text;
import java.util.function.*;
/** Layar pengaturan NoxRing. Semua perubahan langsung berlaku dan disimpan saat layar ditutup. */
public final class NoxSettingsScreen extends Screen {
  private final Screen parent;
  public NoxSettingsScreen(Screen parent) { super(Text.literal("NoxRing")); this.parent = parent; }

  private static final class Sl extends SliderWidget {
    private final String label; private final DoubleFunction<String> fmt; private final DoubleConsumer apply;
    Sl(int x, int y, int w, String label, double v, DoubleFunction<String> fmt, DoubleConsumer apply) { super(x, y, w, 20, Text.empty(), v); this.label = label; this.fmt = fmt; this.apply = apply; updateMessage(); }
    @Override protected void updateMessage() { setMessage(Text.literal(label + ": " + fmt.apply(value))); }
    @Override protected void applyValue() { apply.accept(value); }
  }
  private ButtonWidget cycle(int x, int y, int w, String label, String[] vals, Supplier<String> get, Consumer<String> set) {
    ButtonWidget[] self = new ButtonWidget[1];
    self[0] = ButtonWidget.builder(Text.literal(label + ": " + get.get()), b -> {
      int i = 0; for (int k = 0; k < vals.length; k++) if (vals[k].equals(get.get())) i = k;
      set.accept(vals[(i + 1) % vals.length]); self[0].setMessage(Text.literal(label + ": " + get.get())); }).dimensions(x, y, w, 20).build();
    return self[0];
  }
  private ButtonWidget toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
    ButtonWidget[] self = new ButtonWidget[1];
    self[0] = ButtonWidget.builder(Text.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF")), b -> { set.accept(!get.getAsBoolean()); self[0].setMessage(Text.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF"))); }).dimensions(x, y, w, 20).build();
    return self[0];
  }
  private static double toT(int v, int min, int max) { return (Math.log(Math.max(min, v)) - Math.log(min)) / (Math.log(max) - Math.log(min)); }
  private static int fromT(double t, int min, int max) { return (int) Math.round(Math.exp(Math.log(min) + t * (Math.log(max) - Math.log(min)))); }

  @Override protected void init() {
    int w = 220, x = width / 2 - w / 2, y = Math.max(24, height / 2 - 100), s = 24;
    ButtonWidget head = ButtonWidget.builder(Text.literal("NoxRing - Pengaturan Render"), b -> {}).dimensions(x, y - 22, w, 20).build(); head.active = false; addDrawableChild(head);
    addDrawableChild(toggle(x, y, w, "LOD", () -> LodConfig.enabled, v -> LodConfig.enabled = v)); y += s;
    addDrawableChild(new Sl(x, y, w, "Jarak render", toT(LodConfig.renderChunks, 2, LodConfig.MAX_CHUNKS), t -> fromT(t, 2, LodConfig.MAX_CHUNKS) + " chunk", t -> LodConfig.setChunks(fromT(t, 2, LodConfig.MAX_CHUNKS)))); y += s;
    addDrawableChild(cycle(x, y, w, "Backend", new String[]{"auto", "indirect", "classic", "cpu"}, () -> LodConfig.backend, v -> LodManager.setBackend(v))); y += s;
    addDrawableChild(cycle(x, y, w, "Mode shader", new String[]{"auto", "post", "legacy"}, () -> LodConfig.shaderMode, v -> LodConfig.shaderMode = v)); y += s;
    addDrawableChild(toggle(x, y, w, "Generator (singleplayer)", () -> LodConfig.generate, v -> LodConfig.generate = v)); y += s;
    addDrawableChild(new Sl(x, y, w, "Radius generator", LodConfig.genChunks <= 0 ? 0 : toT(LodConfig.genChunks, 1, LodConfig.MAX_CHUNKS), t -> t <= 0.001 ? "mati" : fromT(t, 1, LodConfig.MAX_CHUNKS) + " chunk", t -> LodConfig.genChunks = t <= 0.001 ? 0 : fromT(t, 1, LodConfig.MAX_CHUNKS))); y += s;
    addDrawableChild(new Sl(x, y, w, "Memori cache", toT(LodConfig.memoryMb, 128, 8192), t -> fromT(t, 128, 8192) + " MB", t -> LodConfig.memoryMb = fromT(t, 128, 8192))); y += s + 6;
    addDrawableChild(ButtonWidget.builder(Text.literal("Selesai"), b -> close()).dimensions(x, y, w, 20).build());
  }
  @Override public void close() { LodConfig.save(); if (client != null) client.setScreen(parent); }
}
