package com.noxring.ui;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents; import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.option.OptionsScreen; import net.minecraft.client.gui.screen.option.VideoOptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget; import net.minecraft.text.Text;
/** Menaruh tombol "NoxRing" di menu Options dan Video Settings. */
public final class NoxUi {
  public static void register() {
    ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
      if (screen instanceof OptionsScreen || screen instanceof VideoOptionsScreen)
        Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("NoxRing"), b -> client.setScreen(new NoxSettingsScreen(screen))).dimensions(6, h - 26, 90, 20).build());
    });
  }
}
