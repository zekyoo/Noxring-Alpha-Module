# NoxRing 1.1.0 (belum dikompilasi/diuji oleh Claude - lihat catatan di chat)
- Fix shader: LOD digambar SETELAH Iris selesai (mixin IrisRenderingPipeline.finalizeLevelRendering), bukan ke G-buffer pack.
  Jalur lama (BEFORE_TRANSLUCENT) tetap jadi cadangan jika hook tidak aktif. Config: shaderMode = auto | post | legacy.
- Komposit LOD hanya menulis colortex0 (draw buffer lain dimatikan sementara), state GL (color mask, stencil, polygon offset, draw buffers) disimpan/dipulihkan.
- Menu pengaturan: tombol "NoxRing" di Options & Video Settings.
- Command baru: /noxring shader <auto|post|legacy>
