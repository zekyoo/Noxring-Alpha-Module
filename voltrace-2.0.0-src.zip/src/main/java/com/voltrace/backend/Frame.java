package com.voltrace.backend;
import com.voltrace.core.LodOctree;
import org.joml.Matrix4f;
/** Parameter satu frame. Semua posisi dunia dipakai relatif kamera agar presisi float aman sampai 130k blok. */
public record Frame(float[] mvp, double cx, double cy, double cz, float fogStart, float fogEnd, float[] fog, float light,
                    LodOctree tree, Matrix4f view, float tanX, float tanY, double vanillaB, double maxB, Opt o) {
  /** Opsi tampilan: kabut, detail piksel, dan data shadow map. shadowMvp sudah relatif kamera. */
  public record Opt(boolean fogOn, boolean pixel, boolean shadowOn, boolean soft, float[] shadowMvp, float shadowRadius, float shadowTexel, float shadowRange, float[] sun) {
    public static final Opt NONE = new Opt(true, true, false, false, new Matrix4f().get(new float[16]), 1f, 1f, 1f, new float[]{0f, 1f, 0f});
  }
  public Frame with(float[] newMvp, Opt opt) { return new Frame(newMvp, cx, cy, cz, fogStart, fogEnd, fog, light, tree, view, tanX, tanY, vanillaB, maxB, opt); }
  public static float[] sec(LodOctree.Key k, double cx, double cy, double cz) {
    double size = 32.0 * (1L << k.level());
    return new float[]{(float) (k.sx() * size - cx), (float) (k.sy() * size - cy), (float) (k.sz() * size - cz), (float) (1L << k.level())};
  }
}
