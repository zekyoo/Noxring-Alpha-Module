package com.voltrace.backend;
import com.voltrace.core.LodOctree.Key;
import org.lwjgl.opengl.*; import java.util.*;
/** OpenGL 3.2 core (sama dengan syarat Minecraft sendiri): jalan di iGPU/GPU lama. Satu VAO+VBO per section, 1 draw call per section. */
public final class ClassicBackend implements RenderBackend {
  private record Mesh(int vao, int vbo, int count) {}
  private final HashMap<Key, Mesh> meshes = new HashMap<>(); private int prog, uSec;
  public String name() { return "Classic (GL3.2)"; } public boolean wantsMeshes() { return true; }
  public void init() { prog = Shaders.program(Shaders.vs(false), Shaders.FS, "aPos", "aCol"); uSec = GL20.glGetUniformLocation(prog, "aSec"); }
  public void upload(Key k, int[] m) {
    remove(k); if (m.length == 0) return;
    int vao = GL30.glGenVertexArrays(), vbo = GL15.glGenBuffers();
    GL30.glBindVertexArray(vao); GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo); GL15.glBufferData(GL15.GL_ARRAY_BUFFER, m, GL15.GL_STATIC_DRAW);
    GL30.glVertexAttribIPointer(0, 1, GL11.GL_UNSIGNED_INT, 8, 0L); GL30.glVertexAttribIPointer(1, 1, GL11.GL_UNSIGNED_INT, 8, 4L);
    GL20.glEnableVertexAttribArray(0); GL20.glEnableVertexAttribArray(1);
    meshes.put(k, new Mesh(vao, vbo, m.length / 2));
  }
  public void remove(Key k) { Mesh m = meshes.remove(k); if (m != null) { GL30.glDeleteVertexArrays(m.vao()); GL15.glDeleteBuffers(m.vbo()); } }
  public void clear() { for (Key k : new ArrayList<>(meshes.keySet())) remove(k); }
  public void draw(Frame f, List<Key> keys) {
    GL20.glUseProgram(prog); Shaders.uniforms(prog, f);
    for (Key k : keys) { Mesh m = meshes.get(k); if (m == null) continue;
      float[] s = Frame.sec(k, f.cx(), f.cy(), f.cz()); GL20.glUniform4f(uSec, s[0], s[1], s[2], s[3]);
      GL30.glBindVertexArray(m.vao()); GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, m.count()); }
  }
  public void close() { clear(); if (prog != 0) GL20.glDeleteProgram(prog); }
}
