package com.voltrace.backend;
import org.lwjgl.opengl.*;
/** Mode shader pack: LOD digambar dulu ke FBO sendiri (depth sendiri, far plane besar), lalu dikomposit ke framebuffer aktif dengan kedalaman yang dipetakan ke proyeksi vanilla. */
public final class LodTarget {
  private int fbo, col, dep, w, h, prog, vao;
  private static int tex(int w, int h, int fmt, int format, int type) {
    int t = GL11.glGenTextures(); GL11.glBindTexture(GL11.GL_TEXTURE_2D, t);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
    GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, fmt, w, h, 0, format, type, 0L); return t;
  }
  public void ensure(int W, int H) {
    if (fbo != 0 && W == w && H == h) return;
    int prevT = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D), prevF = GL11.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);
    if (fbo != 0) { GL30.glDeleteFramebuffers(fbo); GL11.glDeleteTextures(col); GL11.glDeleteTextures(dep); }
    w = W; h = H; col = tex(w, h, GL11.GL_RGBA8, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE); dep = tex(w, h, GL14.GL_DEPTH_COMPONENT24, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT);
    fbo = GL30.glGenFramebuffers(); GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
    GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, col, 0);
    GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, dep, 0);
    int st = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
    GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, prevF); GL11.glBindTexture(GL11.GL_TEXTURE_2D, prevT);
    if (st != GL30.GL_FRAMEBUFFER_COMPLETE) throw new IllegalStateException("FBO LOD tidak lengkap: " + st);
    if (prog == 0) {
      prog = Shaders.program("#version 150\nout vec2 uv; void main(){ vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2)); uv=p; gl_Position=vec4(p*2.0-1.0,0.0,1.0); }",
        "#version 150\nin vec2 uv; uniform sampler2D uCol; uniform sampler2D uDep; uniform vec4 uP; out vec4 o;\n" +
        "void main(){ vec4 c=texture(uCol,uv); if(c.a<0.5) discard; float d=texture(uDep,uv).r; float ndc=d*2.0-1.0;\n" +
        " float z=2.0*uP.x*uP.y/(uP.y+uP.x-ndc*(uP.y-uP.x)); float dv=uP.w*(z-uP.z)/(z*(uP.w-uP.z));\n" +
        " gl_FragDepth=min(clamp(dv,0.0,1.0),0.9999995); o=vec4(c.rgb,1.0); }");
      vao = GL30.glGenVertexArrays();
    }
  }
  public void begin() { GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo); GL11.glClearColor(0f, 0f, 0f, 0f); GL11.glDepthMask(true); GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT); }
  /** n1,f1 = near/far proyeksi LOD; n,f = near/far proyeksi vanilla. */
  public void end(int prevFbo, float n1, float f1, float n, float f) {
    GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, prevFbo);
    // Shader pack: FBO tujuan punya banyak attachment (colortex0..N). Shader komposit hanya menulis 1 output, jadi attachment lain
    // harus dimatikan; kalau tidak nilainya tak terdefinisi dan merusak pencahayaan pack (terrain jadi abu-abu/rusak).
    if (prevFbo != 0) GL20.glDrawBuffers(GL30.GL_COLOR_ATTACHMENT0);
    GL11.glColorMask(true, true, true, true);
    int unit = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
    GL13.glActiveTexture(GL13.GL_TEXTURE1); int t1 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D); GL11.glBindTexture(GL11.GL_TEXTURE_2D, dep);
    GL13.glActiveTexture(GL13.GL_TEXTURE0); int t0 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D); GL11.glBindTexture(GL11.GL_TEXTURE_2D, col);
    GL20.glUseProgram(prog); GL20.glUniform1i(GL20.glGetUniformLocation(prog, "uCol"), 0); GL20.glUniform1i(GL20.glGetUniformLocation(prog, "uDep"), 1);
    GL20.glUniform4f(GL20.glGetUniformLocation(prog, "uP"), n1, f1, n, f);
    GL11.glEnable(GL11.GL_DEPTH_TEST); GL11.glDepthFunc(GL11.GL_LEQUAL); GL11.glDepthMask(true); GL11.glDisable(GL11.GL_BLEND);
    GL30.glBindVertexArray(vao); GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
    GL13.glActiveTexture(GL13.GL_TEXTURE1); GL11.glBindTexture(GL11.GL_TEXTURE_2D, t1); GL13.glActiveTexture(GL13.GL_TEXTURE0); GL11.glBindTexture(GL11.GL_TEXTURE_2D, t0); GL13.glActiveTexture(unit);
  }
}
