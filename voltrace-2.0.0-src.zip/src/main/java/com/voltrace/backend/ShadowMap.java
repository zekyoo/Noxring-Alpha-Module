package com.voltrace.backend;
import org.lwjgl.opengl.*;
/** Shadow map matahari untuk terrain LOD: FBO hanya-kedalaman. Ukuran bisa diubah di menu (1024/2048/4096). */
public final class ShadowMap {
  private int fbo, tex, size;
  public int size() { return size; }
  public int texture() { return tex; }
  public void ensure(int s) {
    if (fbo != 0 && s == size) return;
    int prevT = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D), prevF = GL11.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);
    if (fbo != 0) { GL30.glDeleteFramebuffers(fbo); GL11.glDeleteTextures(tex); }
    size = s; tex = GL11.glGenTextures(); GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
    GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL14.GL_DEPTH_COMPONENT24, size, size, 0, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, 0L);
    fbo = GL30.glGenFramebuffers(); GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
    GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, tex, 0);
    GL11.glDrawBuffer(GL11.GL_NONE); GL11.glReadBuffer(GL11.GL_NONE);
    int st = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
    GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, prevF); GL11.glBindTexture(GL11.GL_TEXTURE_2D, prevT);
    if (st != GL30.GL_FRAMEBUFFER_COMPLETE) { GL30.glDeleteFramebuffers(fbo); GL11.glDeleteTextures(tex); fbo = 0; throw new IllegalStateException("FBO shadow tidak lengkap: " + st); }
  }
  /** Mulai pass kedalaman. Pemanggil wajib menyimpan/memulihkan viewport sendiri. */
  public void begin() {
    GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo); GL11.glViewport(0, 0, size, size);
    GL11.glDisable(GL11.GL_SCISSOR_TEST); GL11.glColorMask(false, false, false, false); GL11.glDepthMask(true); GL11.glEnable(GL11.GL_DEPTH_TEST); GL11.glDepthFunc(GL11.GL_LEQUAL);
    GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
  }
  public void end() { GL11.glColorMask(true, true, true, true); }
  public void close() { if (fbo != 0) { GL30.glDeleteFramebuffers(fbo); GL11.glDeleteTextures(tex); fbo = 0; } }
}
