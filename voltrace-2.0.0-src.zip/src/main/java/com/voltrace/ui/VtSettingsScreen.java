package com.voltrace.ui;
import com.voltrace.LodConfig; import com.voltrace.LodManager;
import net.minecraft.client.gui.screen.Screen; import net.minecraft.client.gui.tooltip.Tooltip; import net.minecraft.client.gui.widget.ButtonWidget; import net.minecraft.client.gui.widget.ClickableWidget; import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import java.util.function.*;
/** Menu pengaturan VolTrace, tersusun seperti Voxy: tab General / Rendering / Shadow. Semua perubahan langsung berlaku dan disimpan saat layar ditutup. */
public final class VtSettingsScreen extends Screen {
  private static int page = 0;
  private static final String[] TABS = {"General", "Rendering", "Shadow"};
  private final Screen parent; private ButtonWidget stats; private int tickN;
  public VtSettingsScreen(Screen parent) { super(Text.literal("VolTrace")); this.parent = parent; }

  private static final class Sl extends SliderWidget {
    private final String label; private final DoubleFunction<String> fmt; private final DoubleConsumer apply;
    Sl(int x, int y, int w, String label, double v, DoubleFunction<String> fmt, DoubleConsumer apply, String tip) {
      super(x, y, w, 20, Text.empty(), Math.max(0, Math.min(1, v))); this.label = label; this.fmt = fmt; this.apply = apply; setTooltip(Tooltip.of(Text.literal(tip))); updateMessage();
    }
    @Override protected void updateMessage() { setMessage(Text.literal(label + ": " + fmt.apply(value))); }
    @Override protected void applyValue() { apply.accept(value); }
  }
  private ButtonWidget cycle(int x, int y, int w, String label, String[] vals, Supplier<String> get, Consumer<String> set, String tip) {
    ButtonWidget[] self = new ButtonWidget[1];
    self[0] = ButtonWidget.builder(Text.literal(label + ": " + get.get()), b -> {
      int i = 0; for (int k = 0; k < vals.length; k++) if (vals[k].equals(get.get())) i = k;
      set.accept(vals[(i + 1) % vals.length]); self[0].setMessage(Text.literal(label + ": " + get.get())); }).dimensions(x, y, w, 20).tooltip(Tooltip.of(Text.literal(tip))).build();
    return self[0];
  }
  private ButtonWidget toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set, String tip) {
    ButtonWidget[] self = new ButtonWidget[1];
    self[0] = ButtonWidget.builder(Text.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF")), b -> { set.accept(!get.getAsBoolean()); self[0].setMessage(Text.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF"))); })
      .dimensions(x, y, w, 20).tooltip(Tooltip.of(Text.literal(tip))).build();
    return self[0];
  }
  private static double toT(int v, int min, int max) { return (Math.log(Math.max(min, v)) - Math.log(min)) / (Math.log(max) - Math.log(min)); }
  private static int fromT(double t, int min, int max) { return (int) Math.round(Math.exp(Math.log(min) + t * (Math.log(max) - Math.log(min)))); }
  private static double lin(int v, int min, int max) { return (v - min) / (double) (max - min); }
  private static int unlin(double t, int min, int max) { return (int) Math.round(min + t * (max - min)); }

  @Override protected void init() {
    int cw = Math.min(160, (width - 24) / 2), gap = 6, x0 = width / 2 - cw - gap / 2, x1 = width / 2 + gap / 2, top = Math.max(8, Math.min(30, height / 2 - 120));
    // judul + baris tab
    ButtonWidget head = ButtonWidget.builder(Text.literal("VolTrace - Pengaturan"), b -> {}).dimensions(width / 2 - cw - gap / 2, top, cw * 2 + gap, 20).build(); head.active = false; addDrawableChild(head);
    int tw = Math.min(80, (cw * 2 + gap - 4) / 3);
    for (int i = 0; i < TABS.length; i++) { final int p = i;
      ButtonWidget tb = ButtonWidget.builder(Text.literal((i == page ? "> " : "") + TABS[i]), b -> { page = p; clearAndInit(); }).dimensions(width / 2 - (tw * 3 + 4) / 2 + i * (tw + 2), top + 24, tw, 20).build(); addDrawableChild(tb); }
    int y = top + 52, s = 24; ClickableWidget[] col = new ClickableWidget[8]; int n = 0;
    switch (page) {
      case 0 -> {
        col[n++] = toggle(0, 0, cw, "Enable VolTrace", () -> LodConfig.enabled, v -> LodConfig.enabled = v, "Menyalakan/mematikan seluruh mod.");
        col[n++] = toggle(0, 0, cw, "VolTrace Rendering", () -> LodConfig.rendering, v -> LodConfig.rendering = v, "Menggambar LOD jarak jauh. Kalau OFF, chunk tetap disimpan tapi tidak ditampilkan.");
        col[n++] = toggle(0, 0, cw, "Chunk Ingest", () -> LodConfig.ingest, v -> LodConfig.ingest = v, "Mengubah chunk yang kamu muat (dan chunk hasil generator) menjadi data LOD.");
        col[n++] = new Sl(0, 0, cw, "Service threads", lin(LodConfig.serviceThreads, 1, 16), t -> "" + unlin(t, 1, 16), t -> { LodConfig.serviceThreads = unlin(t, 1, 16); LodManager.applyThreads(); }, "Jumlah thread untuk membangun mesh & memproses chunk. Lebih banyak = LOD cepat siap tapi CPU lebih berat.");
        col[n++] = new Sl(0, 0, cw, "Memori cache", toT(LodConfig.memoryMb, 128, 8192), t -> fromT(t, 128, 8192) + " MB", t -> LodConfig.memoryMb = fromT(t, 128, 8192), "Batas RAM untuk data LOD. Sisanya dibaca dari disk saat dibutuhkan.");
      }
      case 1 -> {
        col[n++] = new Sl(0, 0, cw, "Render distance", toT(LodConfig.renderChunks, 2, LodConfig.MAX_CHUNKS), t -> fromT(t, 2, LodConfig.MAX_CHUNKS) + " chunk", t -> LodConfig.setChunks(fromT(t, 2, LodConfig.MAX_CHUNKS)), "Jarak LOD dalam chunk. Default 64.");
        col[n++] = new Sl(0, 0, cw, "Subdivision (px^2)", lin(LodConfig.subdivision, 16, 256), t -> "" + unlin(t, 16, 256), t -> LodConfig.subdivision = unlin(t, 16, 256), "Ukuran subdivisi layar sebelum beralih ke LOD lebih kasar. Lebih KECIL = detail jauh lebih tinggi (dan lebih berat).");
        col[n++] = toggle(0, 0, cw, "Render fog", () -> LodConfig.renderFog, v -> LodConfig.renderFog = v, "Kabut yang memudarkan LOD di tepi jarak render.");
        col[n++] = toggle(0, 0, cw, "Environmental fog", () -> LodConfig.envFog, v -> LodConfig.envFog = v, "Warna kabut mengikuti siang/malam dan berubah saat di dalam air.");
        col[n++] = toggle(0, 0, cw, "Pixel detail", () -> LodConfig.pixelDetail, v -> LodConfig.pixelDetail = v, "Detail piksel ala tekstur pada LOD yang dekat dengan kamera.");
        col[n++] = cycle(0, 0, cw, "Backend", new String[]{"auto", "indirect", "classic", "cpu"}, () -> LodConfig.backend, v -> LodManager.setBackend(v), "auto: GPU modern (GL4.3) / klasik (GL3.2). cpu: cadangan untuk perangkat tanpa dukungan GPU.");
        col[n++] = cycle(0, 0, cw, "Mode shader", new String[]{"auto", "post", "legacy"}, () -> LodConfig.shaderMode, v -> LodConfig.shaderMode = v, "Cara menggambar bersama shader pack (Iris). auto sudah tepat untuk hampir semua kasus.");
      }
      case 2 -> {
        col[n++] = toggle(0, 0, cw, "Shadows", () -> LodConfig.shadows, v -> LodConfig.shadows = v, "Bayangan matahari pada terrain LOD (shadow map).");
        col[n++] = new Sl(0, 0, cw, "Shadow radius", toT(LodConfig.shadowChunks, 4, 1024), t -> fromT(t, 4, 1024) + " chunk", t -> LodConfig.shadowChunks = fromT(t, 4, 1024), "Radius bayangan dari kamera. Default 64. Makin besar makin kasar (resolusi terbagi rata).");
        col[n++] = cycle(0, 0, cw, "Shadow resolution", new String[]{"1024", "2048", "4096"}, () -> "" + LodConfig.shadowRes, v -> LodConfig.shadowRes = Integer.parseInt(v), "Resolusi shadow map. 4096 lebih tajam tapi memakai VRAM lebih banyak.");
        col[n++] = toggle(0, 0, cw, "Soft shadows", () -> LodConfig.shadowSoft, v -> LodConfig.shadowSoft = v, "Tepi bayangan dihaluskan (PCF 3x3).");
      }
      default -> {}
    }
    for (int i = 0; i < n; i++) { ClickableWidget wd = col[i]; wd.setX(i % 2 == 0 ? x0 : x1); wd.setY(y + (i / 2) * s); addDrawableChild(wd); }
    y += ((n + 1) / 2) * s + 10;
    addDrawableChild(ButtonWidget.builder(Text.literal("Reset default"), b -> { LodConfig.resetDefaults(); LodManager.applyThreads(); LodManager.setBackend("auto"); clearAndInit(); }).dimensions(x0, y, cw, 20).build());
    addDrawableChild(ButtonWidget.builder(Text.literal("Selesai"), b -> close()).dimensions(x1, y, cw, 20).build());
    stats = ButtonWidget.builder(Text.literal(LodManager.shortStatus()), b -> {}).dimensions(x0, y + 24, cw * 2 + gap, 20).build(); stats.active = false; addDrawableChild(stats);
  }
  @Override public void tick() { super.tick(); if (stats != null && ++tickN % 10 == 0) stats.setMessage(Text.literal(LodManager.shortStatus())); }
  @Override public void close() { LodConfig.save(); if (client != null) client.setScreen(parent); }
}
