package com.voltrace.ui;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents; import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.screen.option.OptionsScreen; import net.minecraft.client.gui.screen.option.VideoOptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget; import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
/** Pintu masuk ke menu pengaturan: tombol di Options, di layar Video Settings (termasuk Sodium), tombol keyboard V, dan /voltrace menu. */
public final class VtUi {
  private static boolean keyDown;
  public static void open() { MinecraftClient mc = MinecraftClient.getInstance(); mc.execute(() -> mc.setScreen(new VtSettingsScreen(mc.currentScreen))); }
  public static void register() {
    ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
      if (screen instanceof VtSettingsScreen) return;
      String n = screen.getClass().getName().toLowerCase();
      boolean options = screen instanceof OptionsScreen, video = screen instanceof VideoOptionsScreen || n.contains("videooptions") || n.contains("videosettings") || n.contains("sodium");
      if (!options && !video) return;
      // Options: pojok kiri-atas (kosong). Video/Sodium: pojok kiri-bawah supaya tidak menimpa tab Sodium.
      int y = options ? 6 : h - 26;
      Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("VolTrace"), b -> client.setScreen(new VtSettingsScreen(screen))).dimensions(6, y, 80, 20).build());
    });
    // Tombol V membuka menu saat tidak ada layar lain (tidak mengganggu chat). Dipoll lewat GLFW agar tidak bergantung API KeyBinding yang berubah-ubah antar versi.
    ClientTickEvents.END_CLIENT_TICK.register(mc -> {
      if (mc.getWindow() == null) return;
      boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_V) == GLFW.GLFW_PRESS;
      if (down && !keyDown && mc.currentScreen == null && mc.world != null) mc.setScreen(new VtSettingsScreen(null));
      keyDown = down;
    });
  }
}
