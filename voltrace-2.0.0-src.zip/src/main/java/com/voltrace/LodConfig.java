package com.voltrace;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*; import java.nio.file.*; import java.util.Properties;
/** Semua pengaturan VolTrace. Nama & arti disamakan dengan menu Voxy (General / Rendering) + tambahan Shadow dan Generator. */
public final class LodConfig {
  public static final int MAX_CHUNKS = 8192;
  // --- General ---
  public static volatile boolean enabled = true;          // "Enable VolTrace" (master)
  public static volatile boolean rendering = true;        // "VolTrace Rendering" (gambar LOD saja, ingest tetap jalan)
  public static volatile boolean ingest = true;           // "Chunk Ingest" (ubah chunk baru jadi LOD)
  public static volatile int serviceThreads = Math.max(1, Runtime.getRuntime().availableProcessors() / 2);
  // --- Rendering ---
  public static volatile int renderChunks = 64;           // "Render distance" (chunk)
  public static volatile int subdivision = 64;            // "Pixels^2 of subdivision size" (kecil = detail tinggi)
  public static volatile boolean renderFog = true;
  public static volatile boolean envFog = true;           // "environmental fog": warna kabut ikut siang/malam & di dalam air
  public static volatile boolean pixelDetail = true;      // detail piksel ala tekstur dekat kamera
  public static volatile String backend = "auto";         // auto | indirect | classic | cpu
  public static volatile String shaderMode = "auto";      // auto | post | legacy
  // --- Shadow ---
  public static volatile boolean shadows = true;
  public static volatile int shadowChunks = 64;           // radius shadow (chunk)
  public static volatile int shadowRes = 2048;            // 1024 | 2048 | 4096
  public static volatile boolean shadowSoft = true;
  public static volatile int memoryMb = 1024;

  public static int setChunks(int c) { return renderChunks = Math.max(2, Math.min(MAX_CHUNKS, c)); }
  public static void resetDefaults() {
    enabled = true; rendering = true; ingest = true; serviceThreads = Math.max(1, Runtime.getRuntime().availableProcessors() / 2);
    renderChunks = 64; subdivision = 64; renderFog = true; envFog = true; pixelDetail = true; backend = "auto"; shaderMode = "auto";
    shadows = true; shadowChunks = 64; shadowRes = 2048; shadowSoft = true;
    memoryMb = 1024;
  }
  private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("voltrace.properties"); }
  private static int i(Properties p, String k, int d, int lo, int hi) { try { return Math.max(lo, Math.min(hi, Integer.parseInt(p.getProperty(k, "" + d).trim()))); } catch (NumberFormatException e) { return d; } }
  private static boolean b(Properties p, String k, boolean d) { return Boolean.parseBoolean(p.getProperty(k, "" + d).trim()); }
  public static void load() {
    Properties p = new Properties();
    try (InputStream in = Files.newInputStream(file())) { p.load(in); } catch (IOException e) { return; }
    enabled = b(p, "enabled", true); rendering = b(p, "rendering", true); ingest = b(p, "ingest", true); serviceThreads = i(p, "serviceThreads", serviceThreads, 1, 32);
    renderChunks = i(p, "renderChunks", 64, 2, MAX_CHUNKS); subdivision = i(p, "subdivision", 64, 16, 256); renderFog = b(p, "renderFog", true); envFog = b(p, "envFog", true);
    pixelDetail = b(p, "pixelDetail", true); backend = p.getProperty("backend", "auto"); shaderMode = p.getProperty("shaderMode", "auto");
    shadows = b(p, "shadows", true); shadowChunks = i(p, "shadowChunks", 64, 4, 1024); shadowRes = i(p, "shadowRes", 2048, 512, 8192); shadowSoft = b(p, "shadowSoft", true);
    memoryMb = i(p, "memoryMb", 1024, 128, 16384);
  }
  public static void save() {
    Properties p = new Properties();
    p.setProperty("enabled", "" + enabled); p.setProperty("rendering", "" + rendering); p.setProperty("ingest", "" + ingest); p.setProperty("serviceThreads", "" + serviceThreads);
    p.setProperty("renderChunks", "" + renderChunks); p.setProperty("subdivision", "" + subdivision); p.setProperty("renderFog", "" + renderFog); p.setProperty("envFog", "" + envFog);
    p.setProperty("pixelDetail", "" + pixelDetail); p.setProperty("backend", backend); p.setProperty("shaderMode", shaderMode);
    p.setProperty("shadows", "" + shadows); p.setProperty("shadowChunks", "" + shadowChunks); p.setProperty("shadowRes", "" + shadowRes); p.setProperty("shadowSoft", "" + shadowSoft);
    p.setProperty("memoryMb", "" + memoryMb);
    try (OutputStream o = Files.newOutputStream(file())) { p.store(o, "VolTrace"); } catch (IOException ignored) {}
  }
}
