package com.voltrace;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
public class VolTrace implements ClientModInitializer {
  public static final String MOD_ID = "voltrace";
  public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
  @Override public void onInitializeClient() {
    LodConfig.load(); LodManager.applyThreads();
    ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> LodManager.onChunk(chunk));
    ClientChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> LodManager.onChunk(chunk));   // simpan keadaan terakhir chunk sebelum hilang
    ClientTickEvents.END_CLIENT_TICK.register(LodManager::tick);
    // LOD digambar setelah terrain solid + entitas, sebelum translucent. Tidak memakai objek context agar tahan perubahan API.
    WorldRenderEvents.BEFORE_TRANSLUCENT.register(ctx -> LodManager.renderLegacy());
    com.voltrace.ui.VtUi.register();
    ClientLifecycleEvents.CLIENT_STOPPING.register(c -> LodManager.shutdown());
    ClientCommandRegistrationCallback.EVENT.register((d, r) -> VtCommands.register(d));
    LOGGER.info("VolTrace LOD siap (maks {} chunk, default {} chunk). Tekan V atau buka Options > VolTrace untuk pengaturan.", LodConfig.MAX_CHUNKS, LodConfig.renderChunks);
  }
}
