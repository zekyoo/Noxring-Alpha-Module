package com.voltrace;
import com.mojang.brigadier.CommandDispatcher; import com.mojang.brigadier.arguments.*;
import net.fabricmc.fabric.api.client.command.v2.*; import net.minecraft.text.Text;
final class VtCommands {
  private static void say(com.mojang.brigadier.context.CommandContext<FabricClientCommandSource> c, String s) { c.getSource().sendFeedback(Text.literal(s)); }
  static void register(CommandDispatcher<FabricClientCommandSource> d) {
    d.register(ClientCommandManager.literal("voltrace")
      .then(ClientCommandManager.literal("menu").executes(c -> { com.voltrace.ui.VtUi.open(); return 1; }))
      .then(ClientCommandManager.literal("distance").then(ClientCommandManager.argument("chunks", IntegerArgumentType.integer(2, LodConfig.MAX_CHUNKS)).executes(c -> {
        int v = LodConfig.setChunks(IntegerArgumentType.getInteger(c, "chunks")); LodConfig.save(); say(c, "VolTrace jarak = " + v + " chunk"); return 1; })))
      .then(ClientCommandManager.literal("shadow").then(ClientCommandManager.argument("chunks", IntegerArgumentType.integer(0, 1024)).executes(c -> {
        int v = IntegerArgumentType.getInteger(c, "chunks"); LodConfig.shadows = v > 0; if (v > 0) LodConfig.shadowChunks = Math.max(4, v); LodConfig.save(); say(c, v > 0 ? "VolTrace shadow radius = " + LodConfig.shadowChunks + " chunk" : "VolTrace shadow mati"); return 1; })))
      .then(ClientCommandManager.literal("backend").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
        String n = StringArgumentType.getString(c, "name"); LodManager.setBackend(n); LodConfig.save(); say(c, "VolTrace backend = " + n + " (auto|indirect|classic|cpu)"); return 1; })))
      .then(ClientCommandManager.literal("reload").executes(c -> { LodColors.reload(net.minecraft.client.MinecraftClient.getInstance()); say(c, "VolTrace warna blok dimuat ulang dari resource pack"); return 1; }))
      .then(ClientCommandManager.literal("shader").then(ClientCommandManager.argument("mode", StringArgumentType.word()).executes(c -> {
        String m = StringArgumentType.getString(c, "mode"); if (!m.equals("auto") && !m.equals("post") && !m.equals("legacy")) { say(c, "Pilih: auto | post | legacy"); return 0; }
        LodConfig.shaderMode = m; LodConfig.save(); say(c, "VolTrace mode shader = " + m); return 1; })))
      .then(ClientCommandManager.literal("toggle").executes(c -> { LodConfig.enabled = !LodConfig.enabled; LodConfig.save(); say(c, "VolTrace " + (LodConfig.enabled ? "aktif" : "mati")); return 1; }))
      .then(ClientCommandManager.literal("status").executes(c -> { say(c, LodManager.status()); return 1; })));
  }
}
