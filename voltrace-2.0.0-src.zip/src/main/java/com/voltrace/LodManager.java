package com.voltrace;
import com.voltrace.backend.*; import com.voltrace.core.*; import com.voltrace.core.LodOctree.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.world.ClientWorld; import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f; import org.joml.Quaternionf; import org.lwjgl.opengl.*;
import java.nio.file.Path; import java.util.*; import java.util.concurrent.*; import java.util.concurrent.atomic.AtomicBoolean;
/** Pusat koordinasi: ingest chunk -> pilih section terlihat per ring LOD -> bangun mesh di worker -> upload & gambar di thread render. */
public final class LodManager {
  /** Level L menutup jarak [ring*2^(L-1), ring*2^L). Ring dasar 768 blok (48 chunk) dan diskalakan oleh "Pixels^2 of subdivision size" (kecil = detail jauh lebih tinggi). */
  static double ring() { return 768.0 * Math.sqrt(64.0 / Math.max(8, LodConfig.subdivision)); }
  static volatile LodOctree tree; static ClientWorld curWorld; static RenderBackend backend; static LodTarget target; static ShadowMap shadowMap;
  static final ConcurrentHashMap<Key, Integer> uploaded = new ConcurrentHashMap<>();
  static final Set<Key> building = ConcurrentHashMap.newKeySet();
  static final ConcurrentLinkedQueue<Built> ready = new ConcurrentLinkedQueue<>();
  static final ConcurrentLinkedQueue<Key> removeQ = new ConcurrentLinkedQueue<>();
  static volatile List<Key> visible = List.of(); static volatile double camX, camY, camZ, vanillaB = 192;
  static final AtomicBoolean updating = new AtomicBoolean(); static int tickN; static long lastSave = System.currentTimeMillis();
  static volatile boolean shadowActive;
  static final ThreadPoolExecutor exec = new ThreadPoolExecutor(LodConfig.serviceThreads, LodConfig.serviceThreads, 30, TimeUnit.SECONDS, new LinkedBlockingQueue<>(),
    r -> { Thread t = new Thread(r, "voltrace-worker"); t.setDaemon(true); t.setPriority(Thread.NORM_PRIORITY - 1); return t; });
  static { exec.allowCoreThreadTimeOut(true); }
  record Built(LodOctree t, Key key, int[] mesh, int ver) {}

  /** "Service threads" di menu: ukuran pool diubah langsung tanpa restart. */
  public static void applyThreads() {
    int n = Math.max(1, Math.min(32, LodConfig.serviceThreads));
    if (n > exec.getMaximumPoolSize()) { exec.setMaximumPoolSize(n); exec.setCorePoolSize(n); } else { exec.setCorePoolSize(n); exec.setMaximumPoolSize(n); }
  }

  // ---------- dunia ----------
  static void ensureWorld(MinecraftClient mc) {
    ClientWorld w = mc.world; if (w == curWorld) return;
    closeWorld(); curWorld = w; if (w == null) return;
    String base = mc.isInSingleplayer() && mc.getServer() != null ? "sp_" + mc.getServer().getSaveProperties().getLevelName()
      : "mp_" + (mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "unknown");
    String id = (base + "__" + w.getRegistryKey().getValue()).replaceAll("[^A-Za-z0-9._-]", "_");
    Path dir = FabricLoader.getInstance().getGameDir().resolve("voltrace").resolve(id);
    tree = new LodOctree(dir); LodColors.reload(mc); uploaded.clear(); building.clear(); ready.clear(); removeQ.clear(); visible = List.of();
    if (backend != null) backend.clear();
  }
  static void closeWorld() { LodOctree t = tree; tree = null; if (t != null) t.saveAll(); }
  public static void shutdown() { closeWorld(); LodConfig.save(); }

  public static void onChunk(WorldChunk chunk) {
    MinecraftClient mc = MinecraftClient.getInstance(); ensureWorld(mc);
    LodOctree t = tree; if (t == null || !LodConfig.enabled || !LodConfig.ingest) return;
    exec.execute(() -> { try { ChunkIngest.run(t, chunk); } catch (Throwable e) { VolTrace.LOGGER.warn("ingest gagal: {}", e.toString()); } });
  }
  public static void tick(MinecraftClient mc) {
    ensureWorld(mc); if (tree == null || !LodConfig.enabled) return;
    if (++tickN % 5 == 0 && updating.compareAndSet(false, true)) exec.execute(() -> { try { update(); } catch (Throwable e) { e.printStackTrace(); } finally { updating.set(false); } });
  }

  // ---------- pemilihan section + build mesh (worker) ----------
  static void update() {
    LodOctree t = tree; RenderBackend be = backend; if (t == null || be == null) return;
    long now = System.currentTimeMillis(); if (now - lastSave > 30000) { lastSave = now; t.evict(LodConfig.memoryMb * 1024L * 1024L); t.saveDirty(); }
    if (!be.wantsMeshes() || !LodConfig.rendering) { visible = List.of(); return; }
    double cx = camX, cz = camZ, vb = vanillaB, maxB = LodConfig.renderChunks * 16.0, RING = ring(); List<Key> vis = new ArrayList<>();
    for (int L = 0; L <= LodOctree.MAX_LEVEL; L++) {
      double lo = L == 0 ? 0 : RING * (1L << (L - 1)), hi = Math.min(RING * (double) (1L << L), maxB); if (lo >= maxB) break;
      int size = 32 << L, x0 = Math.floorDiv((int) (cx - hi - size), size), x1 = Math.floorDiv((int) (cx + hi + size), size), z0 = Math.floorDiv((int) (cz - hi - size), size), z1 = Math.floorDiv((int) (cz + hi + size), size);
      for (int sx = x0; sx <= x1; sx++) for (int sz = z0; sz <= z1; sz++) {
        double d = Math.hypot(sx * (double) size + size / 2.0 - cx, sz * (double) size + size / 2.0 - cz);
        if (d < lo || d >= hi || (L == 0 && d + size * 0.71 < vb)) continue;
        Column col = t.column(new CK(L, sx, sz), false); if (col == null) continue;
        for (var e : col.secs.entrySet()) if (!e.getValue().isEmpty()) vis.add(new Key(L, sx, e.getKey(), sz));
      }
    }
    visible = vis; Set<Key> vs = new HashSet<>(vis); List<Key> need = new ArrayList<>();
    for (Key k : vis) { Section s = t.get(k); Integer up = uploaded.get(k); if (s != null && !building.contains(k) && (up == null || up != s.version)) need.add(k); }
    need.sort(Comparator.comparingDouble(k -> { double sz = 32.0 * (1L << k.level()); return Math.hypot(k.sx() * sz - cx, k.sz() * sz - cz); }));
    for (Key k : need) { if (building.size() >= 64) break; if (building.add(k)) exec.execute(() -> build(t, k)); }
    for (Key k : uploaded.keySet()) if (!vs.contains(k)) removeQ.add(k);
  }
  static void build(LodOctree t, Key k) {
    try { Section s = t.get(k); if (s == null) return; int ver = s.version; ready.add(new Built(t, k, Mesher.mesh(t, k), ver)); }
    catch (Throwable e) { e.printStackTrace(); } finally { building.remove(k); }
  }

  // ---------- pemilihan jalur render ----------
  static volatile long postStamp;
  static boolean usePost() { String m = LodConfig.shaderMode; if (m.equals("legacy")) return false; if (m.equals("post")) return true; return IrisCompat.packActive(); }
  /** Event BEFORE_TRANSLUCENT (vanilla). Dengan shader pack aktif jalur ini dilewati selama hook pasca-Iris hidup; kalau hook tidak ada, tetap dipakai sebagai cadangan. */
  public static void renderLegacy() { if (usePost() && System.currentTimeMillis() - postStamp < 1500) return; render(); }
  /** Dipanggil mixin setelah Iris selesai (framebuffer akhir sudah berisi hasil shader pack). */
  public static void renderPost() { postStamp = System.currentTimeMillis(); if (usePost()) render(); }

  /** Arah matahari (menuju matahari) dari waktu dunia. Siang = y positif; timur = +X (matahari terbit di timur). */
  static float[] sunDir(double timeOfDay) {
    double sa = ((timeOfDay % 24000.0) / 24000.0) - 0.25, phi = sa * Math.PI * 2.0;
    double x = -Math.sin(phi), y = Math.cos(phi), z = 0.25, l = Math.sqrt(x * x + y * y + z * z);
    return new float[]{(float) (x / l), (float) (y / l), (float) (z / l)};
  }

  /** Selalu lewat FBO sendiri + komposit berkedalaman ala vanilla: aman terhadap depth vanilla, translucent, dan shader pack. */
  public static void render() {
    LodOctree t = tree; MinecraftClient mc = MinecraftClient.getInstance();
    if (t == null || !LodConfig.enabled || !LodConfig.rendering || mc.world == null) return;
    GlSnapshot snap = new GlSnapshot(); snap.prepare();
    try {
      var camera = mc.gameRenderer.getCamera(); var cp = camera.getCameraPos(); camX = cp.x; camY = cp.y; camZ = cp.z;
      vanillaB = mc.options.getClampedViewDistance() * 16.0;
      if (backend == null) { backend = BackendSelector.select(); backend.init(); VolTrace.LOGGER.info("backend: {}", backend.name()); }
      int budget = 6; Built b;
      while (budget > 0 && (b = ready.poll()) != null) { if (b.t() != t) continue; backend.upload(b.key(), b.mesh()); uploaded.put(b.key(), b.ver()); budget--; }
      Key rk; while ((rk = removeQ.poll()) != null) { backend.remove(rk); uploaded.remove(rk); }
      int[] vpt = new int[4]; GL11.glGetIntegerv(GL11.GL_VIEWPORT, vpt); if (vpt[2] <= 0 || vpt[3] <= 0) return;
      float aspect = (float) vpt[2] / vpt[3], fovY = (float) Math.toRadians(mc.options.getFov().getValue()), tanY = (float) Math.tan(fovY / 2f), maxB = LodConfig.renderChunks * 16f;
      float near = (float) Math.min(48.0, Math.max(4.0, vanillaB * 0.25)), far = Math.max(2048f, maxB * 1.25f);
      Matrix4f proj = new Matrix4f().perspective(fovY, aspect, near, far), view = new Matrix4f().rotation(camera.getRotation().conjugate(new Quaternionf()));
      float[] mvp = new float[16]; proj.mul(view, new Matrix4f()).get(mvp);
      double tod = mc.world.getTimeOfDay();
      double dd = ((tod / 24000.0) % 1.0 - 0.25 + 1.0) % 1.0, ang = (dd * 2.0 + (0.5 - Math.cos(dd * Math.PI) / 2.0)) / 3.0;
      float day = (float) Math.max(0.1, Math.min(1.0, Math.cos(ang * Math.PI * 2) * 2 + 0.5));
      // kabut: "environmental fog" = ikut siang/malam dan berubah di dalam air
      float[] fogC = LodConfig.envFog ? new float[]{0.72f * day, 0.82f * day, day} : new float[]{0.72f, 0.82f, 1.0f};
      float fs = maxB * 0.55f, fe = maxB;
      if (LodConfig.envFog && mc.player != null && mc.player.isSubmergedInWater()) { fogC = new float[]{0.05f * day + 0.02f, 0.12f * day + 0.04f, 0.35f * day + 0.1f}; fs = 4f; fe = Math.min(maxB, 96f); }
      Frame.Opt opt0 = new Frame.Opt(LodConfig.renderFog, LodConfig.pixelDetail, false, false, Frame.Opt.NONE.shadowMvp(), 1f, 1f, 1f, new float[]{0f, 1f, 0f});
      Frame f = new Frame(mvp, camX, camY, camZ, fs, fe, fogC, day, t, view, tanY * aspect, tanY, vanillaB, maxB, opt0);
      if (target == null) target = new LodTarget(); target.ensure(vpt[2], vpt[3]);
      // ---- shadow map matahari (hanya terrain LOD; Iris/vanilla punya bayangan sendiri) ----
      shadowActive = false; float[] sun = sunDir(tod);
      if (LodConfig.shadows && backend.wantsMeshes() && sun[1] > 0.08f) {
        try { f = renderShadow(f, sun, vpt, snap); } catch (Throwable e) { VolTrace.LOGGER.warn("shadow dimatikan sementara: {}", e.toString()); LodConfig.shadows = false; f = f.with(mvp, opt0); }
        GL11.glViewport(vpt[0], vpt[1], vpt[2], vpt[3]); GL11.glColorMask(true, true, true, true);
      }
      GL11.glEnable(GL11.GL_DEPTH_TEST); GL11.glDepthFunc(GL11.GL_LEQUAL); GL11.glDepthMask(true); GL11.glDisable(GL11.GL_CULL_FACE); GL11.glDisable(GL11.GL_BLEND); GL11.glDisable(GL11.GL_SCISSOR_TEST);
      target.begin();
      if (shadowActive) { GL13.glActiveTexture(GL13.GL_TEXTURE2); GL11.glBindTexture(GL11.GL_TEXTURE_2D, shadowMap.texture()); GL13.glActiveTexture(GL13.GL_TEXTURE0); }
      backend.draw(f, visible);
      // peta kedalaman LOD ke proyeksi vanilla (near 0.05); far ditebak lebih kecil agar LOD selalu "di belakang" terrain vanilla
      target.end(snap.drawFbo(), near, far, 0.05f, (float) Math.max(256.0, vanillaB * 2.0));
    } catch (Throwable e) { fallback(e); }
    finally { snap.restore(); }
  }

  /** Gambar kedalaman terrain LOD dari arah matahari ke shadow map (ortho, berpusat di kamera, di-snap per texel agar tidak berkedip). */
  private static Frame renderShadow(Frame f, float[] sun, int[] vpt, GlSnapshot snap) {
    if (shadowMap == null) shadowMap = new ShadowMap();
    int res = LodConfig.shadowRes; res = res >= 4096 ? 4096 : res >= 2048 ? 2048 : 1024; shadowMap.ensure(res);
    float R = (float) Math.min(LodConfig.shadowChunks * 16.0, LodConfig.renderChunks * 16.0), zr = R + 512f, texel = 2f * R / res;
    Matrix4f lv = new Matrix4f().lookAt(0f, 0f, 0f, -sun[0], -sun[1], -sun[2], 0f, 0f, 1f);
    double rx = lv.m00(), ry = lv.m10(), rz = lv.m20(), ux = lv.m01(), uy = lv.m11(), uz = lv.m21();
    double px = rx * f.cx() + ry * f.cy() + rz * f.cz(), py = ux * f.cx() + uy * f.cy() + uz * f.cz();
    float tx = (float) (px - Math.floor(px / texel) * texel), ty = (float) (py - Math.floor(py / texel) * texel);
    float[] sm = new float[16]; new Matrix4f().ortho(-R, R, -R, R, -zr, zr).translate(tx, ty, 0f).mul(lv).get(sm);
    List<Key> sk = new ArrayList<>();
    for (Key k : visible) { double sz = 32.0 * (1L << k.level()), ccx = k.sx() * sz + sz / 2, ccz = k.sz() * sz + sz / 2; if (Math.hypot(ccx - f.cx(), ccz - f.cz()) < R + sz * 0.75) sk.add(k); }
    Frame.Opt off = new Frame.Opt(false, false, false, false, sm, R, texel, 2f * zr, sun);
    GL13.glActiveTexture(GL13.GL_TEXTURE2); GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0); GL13.glActiveTexture(GL13.GL_TEXTURE0);   // hindari feedback loop
    shadowMap.begin(); GL11.glDisable(GL11.GL_CULL_FACE); GL11.glDisable(GL11.GL_BLEND); GL11.glDisable(GL11.GL_SCISSOR_TEST);
    backend.draw(f.with(sm, off), sk);
    shadowMap.end(); GL11.glViewport(vpt[0], vpt[1], vpt[2], vpt[3]);
    shadowActive = true;
    return f.with(f.mvp(), new Frame.Opt(LodConfig.renderFog, LodConfig.pixelDetail, true, LodConfig.shadowSoft, sm, R, texel, 2f * zr, sun));
  }

  /** Backend gagal -> turun otomatis: Indirect -> Classic -> CPU -> mati. */
  static void fallback(Throwable e) {
    VolTrace.LOGGER.error("backend gagal", e);
    String cur = backend == null ? LodConfig.backend : backend.name().toLowerCase();
    try { if (backend != null) backend.close(); } catch (Throwable ignored) {}
    backend = null; uploaded.clear(); ready.clear(); building.clear();
    if (cur.startsWith("indirect") || cur.equals("auto")) LodConfig.backend = "classic"; else if (cur.startsWith("classic")) LodConfig.backend = "cpu"; else LodConfig.enabled = false;
  }
  public static void setBackend(String name) { LodConfig.backend = name; try { if (backend != null) backend.close(); } catch (Throwable ignored) {} backend = null; uploaded.clear(); ready.clear(); }
  public static String status() {
    String mode = usePost() ? "pasca-shader" : "vanilla"; LodOctree t = tree;
    return "mode=" + mode + (IrisCompat.packActive() ? " (shader pack aktif)" : "") + ", backend=" + (backend == null ? "-" : backend.name()) + ", jarak=" + LodConfig.renderChunks + " chunk, section terlihat=" + visible.size()
      + ", di GPU=" + uploaded.size() + ", shadow=" + (shadowActive ? "aktif" : "mati") + ", kolom di RAM=" + (t == null ? 0 : t.columnCount()) + ", chunk di LOD=" + (t == null ? 0 : t.chunkCount()) + "";
  }
  /** Ringkas untuk menu (satu baris). */
  public static String shortStatus() {
    LodOctree t = tree; return (t == null ? "Belum ada dunia" : "LOD: " + t.chunkCount() + " chunk | " + uploaded.size() + " section di GPU") + (backend == null ? "" : " | " + backend.name());
  }
}
