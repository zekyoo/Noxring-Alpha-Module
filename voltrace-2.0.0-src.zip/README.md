# VolTrace (Fabric 1.21.11)
Mod LOD voxel (dulu "NoxRing"): menampilkan chunk jauh beserta warna/teksturnya, cara kerja ala Voxy, jalan di semua GPU/CPU. Hanya client.

## Build
Upload seluruh isi folder ini ke repo GitHub -> tab Actions -> workflow `build` -> unduh artifact `Artifacts` (jar ada di dalamnya).
Atau di PC: `./gradlew build` -> `build/libs/`.

## Membuka menu pengaturan
- `Options` -> tombol **VolTrace** (pojok kiri-atas), atau di layar Video Settings / Sodium (pojok kiri-bawah)
- Tekan **V** saat bermain, atau ketik `/voltrace menu`

Tab: **General** (Enable, Rendering, Chunk Ingest, Service threads, Memori) · **Rendering** (Render distance, Subdivision, Fog, Environmental fog, Pixel detail, Backend, Mode shader) · **Shadow** (ON/OFF, radius, resolusi, soft).

## Default
Render distance **64 chunk**, shadow radius **64 chunk**.

## Perintah `/voltrace ...`
`menu` · `distance <2-8192>` · `shadow <0-1024>` · `backend auto|indirect|classic|cpu` · `reload` · `shader auto|post|legacy` · `toggle` · `status`

## Cara kerja
- Chunk client disalin ke octree LOD (level 0..12), disimpan di `voltrace/<dunia>/`. Data menumpuk antar sesi.
- Seperti Voxy: **tidak ada generate chunk baru**. LOD dibuat dari chunk yang dimuat game (saat load dan saat unload), jadi area baru muncul di LOD setelah kamu mendekatinya sekali; data tersimpan dan menumpuk antar sesi.
- Warna = rata-rata tekstur PNG asli (resource pack ikut) + tint biome; shader menambah detail piksel dekat kamera.
- Shadow: shadow map matahari (ortho, di-snap per texel) hanya untuk terrain LOD.
- Gambar: FBO sendiri -> komposit dengan kedalaman ala vanilla (aman untuk shader pack). Backend: GL4.3 Indirect, GL3.2 Classic, CPU cadangan.
- Multiplayer: LOD hanya dari chunk yang pernah dimuat client .
