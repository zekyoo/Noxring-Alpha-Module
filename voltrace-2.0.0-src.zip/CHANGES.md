# VolTrace 2.0.0 (rename dari NoxRing; belum dikompilasi/diuji di game oleh Claude)
- Rename: id `voltrace`, package `com.voltrace`, command `/voltrace`, config `config/voltrace.properties`, data `voltrace/` (data LOD NoxRing lama tidak dipakai).
- Menu pengaturan baru bertab (General / Rendering / Shadow) meniru opsi Voxy; masuk lewat Options, Video Settings/Sodium, tombol V, atau `/voltrace menu`.
- Default: render distance 64 chunk, shadow radius 64 chunk.
- Generate chunk disamakan dengan Voxy: tidak ada generator; hanya chunk yang dimuat game (load + unload) yang masuk LOD.
- Shadow map matahari untuk terrain LOD (radius, resolusi, soft shadow bisa diatur).
- Opsi baru: Chunk Ingest, VolTrace Rendering, Service threads (tanpa restart), Subdivision size, Render fog, Environmental fog, Pixel detail.
