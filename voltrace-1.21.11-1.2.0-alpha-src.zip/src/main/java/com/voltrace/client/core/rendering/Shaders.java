package com.voltrace.client.core.rendering;
import com.voltrace.client.core.model.TileAtlas;
import org.lwjgl.opengl.*;
final class Shaders {
  private static final float[] IDENT = {1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1};
  /** Sumber GLSL dibaca dari resource (assets/voltrace/shaders/...), seperti Voxy. */
  static String src(String name) {
    try (java.io.InputStream in = Shaders.class.getResourceAsStream("/assets/voltrace/shaders/" + name)) {
      if (in == null) throw new IllegalStateException("shader tidak ditemukan: " + name);
      return new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
    } catch (java.io.IOException e) { throw new IllegalStateException(e); }
  }
  /** perInstance=true: aSec dari atribut instance (MDI, GL 4.3). false: uniform per section (GL 3.2). */
  static String vs(boolean perInstance) { return src("lod/lod.vert").replace("//@SEC@", perInstance ? "in vec4 aSec;" : "uniform vec4 aSec;"); }
  static String fs() { return src("lod/lod.frag"); }
  static String fsShadow() { return src("lod/shadow.frag"); }

  static int program(String vs, String fs, String... attribs) {
    int v = shader(GL20.GL_VERTEX_SHADER, vs), f = shader(GL20.GL_FRAGMENT_SHADER, fs), p = GL20.glCreateProgram();
    GL20.glAttachShader(p, v); GL20.glAttachShader(p, f);
    for (int i = 0; i < attribs.length; i++) GL20.glBindAttribLocation(p, i, attribs[i]);
    GL20.glLinkProgram(p);
    if (GL20.glGetProgrami(p, GL20.GL_LINK_STATUS) == 0) throw new IllegalStateException("link: " + GL20.glGetProgramInfoLog(p));
    GL20.glDeleteShader(v); GL20.glDeleteShader(f); return p;
  }
  static int shader(int type, String src) {
    int s = GL20.glCreateShader(type); GL20.glShaderSource(s, src); GL20.glCompileShader(s);
    if (GL20.glGetShaderi(s, GL20.GL_COMPILE_STATUS) == 0) throw new IllegalStateException("shader: " + GL20.glGetShaderInfoLog(s));
    return s;
  }
  private static int loc(int p, String n) { return GL20.glGetUniformLocation(p, n); }
  static void shadowUniforms(int p, Frame f) { GL20.glUniformMatrix4fv(loc(p, "uMvp"), false, f.mvp()); }
  static void uniforms(int p, Frame f) {
    GL20.glUniformMatrix4fv(loc(p, "uMvp"), false, f.mvp());
    GL20.glUniform3f(loc(p, "uFogColor"), f.fog()[0], f.fog()[1], f.fog()[2]);
    GL20.glUniform2f(loc(p, "uFogRange"), f.fogStart(), f.fogEnd());
    GL20.glUniform1f(loc(p, "uLight"), f.light());
    GL20.glUniform3f(loc(p, "uSun"), f.sun()[0], f.sun()[1], f.sun()[2]);
    GL20.glUniform4f(loc(p, "uOpt"), f.opt()[0], f.opt()[1], f.opt()[2], f.opt()[3]);
    GL20.glUniform4f(loc(p, "uShadowP"), f.shadowP()[0], f.shadowP()[1], f.shadowP()[2], f.shadowP()[3]);
    GL20.glUniformMatrix4fv(loc(p, "uLightMvp"), false, f.lightMvp() != null ? f.lightMvp() : IDENT);
    GL20.glUniform1i(loc(p, "uAtlas"), 2); GL20.glUniform1i(loc(p, "uShadow"), 3);
    GL13.glActiveTexture(GL13.GL_TEXTURE3); GL11.glBindTexture(GL11.GL_TEXTURE_2D, f.shadowTex());
    TileAtlas.bind(2);
    GL13.glActiveTexture(GL13.GL_TEXTURE0);
  }
}
