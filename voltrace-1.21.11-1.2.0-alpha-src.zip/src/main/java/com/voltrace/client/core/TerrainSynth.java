package com.voltrace.client.core;
import com.voltrace.client.core.model.LodColors;
import com.voltrace.common.world.*; import com.voltrace.common.voxelization.*; import com.voltrace.common.world.LodOctree.*;
import net.minecraft.block.*; import net.minecraft.client.MinecraftClient; import net.minecraft.registry.RegistryKey; import net.minecraft.registry.entry.RegistryEntry; import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.server.MinecraftServer; import net.minecraft.server.world.ServerWorld; import net.minecraft.world.Heightmap; import net.minecraft.world.World;
import net.minecraft.world.biome.Biome; import net.minecraft.world.biome.BiomeKeys; import net.minecraft.world.biome.source.BiomeSource; import net.minecraft.world.biome.source.util.MultiNoiseUtil;
import net.minecraft.world.gen.chunk.ChunkGenerator; import net.minecraft.world.gen.noise.NoiseConfig;
import java.util.*;
/**
 * Sintesis terrain jauh (singleplayer): menanyakan tinggi permukaan + biome langsung ke noise generator dunia, TANPA membuat chunk
 * (jadi tidak menyentuh file save dunia dan cepat). Satu "kolom-section" = 32x32 sel pada level LOD tertentu. Hasil ditulis ke octree
 * sebagai voxel lengkap dengan tekstur, lalu menjadi sumber render LOD biasa. Data chunk asli selalu menang atas hasil sintesis.
 */
final class TerrainSynth {
  private record BK(LodColors.Info in, Biome b) {}

  static void run(LodOctree tree, CK ck) {
    MinecraftServer srv = MinecraftClient.getInstance().getServer(); RegistryKey<World> dim = LodManager.curDim; if (srv == null || dim == null) return;
    ServerWorld w = srv.getWorld(dim); if (w == null) return;
    var dt = w.getDimension(); if (!dt.hasSkyLight() || dt.hasCeiling()) { tree.markSynth(ck); return; }   // hanya dimensi ala overworld
    ChunkGenerator gen = w.getChunkManager().getChunkGenerator(); NoiseConfig nc = w.getChunkManager().getNoiseConfig();
    BiomeSource bs = gen.getBiomeSource(); MultiNoiseUtil.MultiNoiseSampler ms = nc.getMultiNoiseSampler();
    final int L = ck.level(), cell = 1 << L, N = 34, sea = gen.getSeaLevel(), minY = w.getBottomY();
    int[] top = new int[N * N], flo = new int[N * N];   // grid 34x34 (border 1 sel) supaya tebing antar-section tidak bolong
    for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
      int bx = (ck.sx() * 32 + i - 1) * cell + cell / 2, bz = (ck.sz() * 32 + j - 1) * cell + cell / 2;
      int t = gen.getHeight(bx, bz, Heightmap.Type.WORLD_SURFACE_WG, w, nc);
      top[j * N + i] = t; flo[j * N + i] = t > sea + 1 ? t : gen.getHeight(bx, bz, Heightmap.Type.OCEAN_FLOOR_WG, w, nc);
    }
    Column col = tree.column(ck, true); HashMap<BK, Short> ids = new HashMap<>(); HashMap<Integer, Section> secs = new HashMap<>();
    BlockState water = Blocks.WATER.getDefaultState(), dirt = Blocks.DIRT.getDefaultState(), stone = Blocks.STONE.getDefaultState();
    for (int j = 0; j < 32; j++) for (int i = 0; i < 32; i++) {
      if (hasSolid(col, i, j)) continue;   // sudah ada data chunk asli di kolom ini
      int g = (j + 1) * N + (i + 1), tp = top[g], fl = flo[g]; if (tp <= minY) continue;
      int bx = (ck.sx() * 32 + i) * cell + cell / 2, bz = (ck.sz() * 32 + j) * cell + cell / 2;
      RegistryEntry<Biome> be = bs.getBiome(bx >> 2, Math.max(tp, sea) >> 2, bz >> 2, ms); Biome bm = be.value();
      boolean wet = tp > fl; int ts = Math.floorDiv(fl - 1, cell), wt = wet ? Math.floorDiv(tp - 1, cell) : ts;
      int mn = Math.min(Math.min(ts, Math.floorDiv(flo[g - 1] - 1, cell)), Math.min(Math.floorDiv(flo[g + 1] - 1, cell), Math.min(Math.floorDiv(flo[g - N] - 1, cell), Math.floorDiv(flo[g + N] - 1, cell))));
      int depth = Math.max(1, Math.min(128, ts - mn + 1)); BlockState surf = surface(be, fl, wet);
      for (int cy = ts - depth + 1; cy <= Math.max(ts, wt); cy++) {
        BlockState st;
        if (cy == ts) st = (wet && wt == ts) ? water : surf;
        else if (cy > ts) st = water;
        else st = (cy == ts - 1 && (surf.isOf(Blocks.GRASS_BLOCK) || surf.isOf(Blocks.MYCELIUM))) ? dirt : stone;
        short id = idOf(tree, ids, st, bm, bx, bz); if (id == 0) continue;
        int sy = Math.floorDiv(cy, 32); Section s = secs.computeIfAbsent(sy, k -> tree.getOrCreate(new Key(L, ck.sx(), k, ck.sz())));
        s.set(i, Math.floorMod(cy, 32), j, id);
      }
    }
    for (var e : secs.entrySet()) { Section s = e.getValue(); s.compact(); s.version++; tree.touch(new Key(L, ck.sx(), e.getKey(), ck.sz())); }
    tree.markSynth(ck);
  }

  private static short idOf(LodOctree t, HashMap<BK, Short> m, BlockState st, Biome bm, int bx, int bz) {
    LodColors.Info in = LodColors.info(st); if (in == LodColors.NONE) return 0;
    return m.computeIfAbsent(new BK(in, in.tinted() ? bm : null), k -> t.palette.idFor(k.in().tinted() ? LodColors.mul(k.in().rgb(), LodColors.tint(k.in(), k.b(), bx, bz)) : k.in().rgb(), k.in().tiles()));
  }
  private static boolean hasSolid(Column col, int i, int j) {
    for (Section s : col.secs.values()) { if (s.isEmpty()) continue; if (s.cells == null) return true; for (int y = 0; y < 32; y++) if (s.at(i, y, j) != 0) return true; }
    return false;
  }
  /** Blok permukaan menurut biome (perkiraan; detail pohon/fitur tidak ada pada sintesis). */
  private static BlockState surface(RegistryEntry<Biome> b, int y, boolean wet) {
    if (wet) return (b.isIn(BiomeTags.IS_DEEP_OCEAN) ? Blocks.GRAVEL : Blocks.SAND).getDefaultState();
    if (b.matchesKey(BiomeKeys.DESERT) || b.isIn(BiomeTags.IS_BEACH)) return Blocks.SAND.getDefaultState();
    if (b.isIn(BiomeTags.IS_BADLANDS)) return (y > 95 ? Blocks.TERRACOTTA : Blocks.RED_SAND).getDefaultState();
    if (b.matchesKey(BiomeKeys.MUSHROOM_FIELDS)) return Blocks.MYCELIUM.getDefaultState();
    if (b.matchesKey(BiomeKeys.SNOWY_PLAINS) || b.matchesKey(BiomeKeys.ICE_SPIKES) || b.matchesKey(BiomeKeys.SNOWY_TAIGA) || b.matchesKey(BiomeKeys.SNOWY_BEACH)
      || b.matchesKey(BiomeKeys.GROVE) || b.matchesKey(BiomeKeys.SNOWY_SLOPES) || b.matchesKey(BiomeKeys.FROZEN_PEAKS) || b.matchesKey(BiomeKeys.JAGGED_PEAKS) || b.matchesKey(BiomeKeys.FROZEN_RIVER)) return Blocks.SNOW_BLOCK.getDefaultState();
    if (b.isIn(BiomeTags.IS_MOUNTAIN) && y > 150) return Blocks.STONE.getDefaultState();
    return Blocks.GRASS_BLOCK.getDefaultState();
  }
}
