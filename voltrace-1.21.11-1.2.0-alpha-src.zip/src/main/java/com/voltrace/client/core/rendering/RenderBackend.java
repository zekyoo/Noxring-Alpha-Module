package com.voltrace.client.core.rendering;
import com.voltrace.common.world.LodOctree.Key; import java.util.List;
public interface RenderBackend {
  String name(); boolean wantsMeshes();
  void init(); void upload(Key k, int[] mesh); void remove(Key k); void clear();
  void draw(Frame f, List<Key> keys); void close();
}
