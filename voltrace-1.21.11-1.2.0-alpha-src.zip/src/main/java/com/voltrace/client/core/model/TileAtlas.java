package com.voltrace.client.core.model;
import net.minecraft.client.MinecraftClient; import net.minecraft.resource.Resource; import net.minecraft.util.Identifier;
import org.lwjgl.BufferUtils; import org.lwjgl.opengl.*;
import javax.imageio.ImageIO; import java.awt.image.BufferedImage; import java.io.InputStream; import java.nio.ByteBuffer; import java.nio.file.*; import java.util.*;
/** Atlas tekstur blok untuk LOD: tiap tekstur blok asli (resource pack ikut) diperkecil ke 16x16 lalu disimpan sebagai 1 layer
 *  GL_TEXTURE_2D_ARRAY (mipmap per layer, tanpa bleeding antar-tile). Daftar tile disimpan per dunia (tiles.txt) agar id di palet stabil. */
public final class TileAtlas {
  public static final int SIZE = 16, MAX = 256;
  private static final Object LOCK = new Object();
  private static final ArrayList<String> names = new ArrayList<>(); private static final HashMap<String, Integer> byName = new HashMap<>();
  private static final int[][] px = new int[MAX][];
  private static Path file; private static int version = 1, uploaded = 0, tex;
  static { names.add(""); }

  /** Buka daftar tile milik dunia ini dan muat ulang pikselnya dari resource pack aktif. */
  public static void open(Path dir) {
    synchronized (LOCK) {
      names.clear(); byName.clear(); Arrays.fill(px, null); names.add(""); file = dir == null ? null : dir.resolve("tiles.txt");
      if (file != null && Files.exists(file)) {
        try { for (String s : Files.readAllLines(file)) { s = s.trim(); if (s.isEmpty() || names.size() >= MAX) continue;
            int id = names.size(); int[] p = load(s); if (p == null) { p = new int[SIZE * SIZE]; Arrays.fill(p, 0xFF808080); } names.add(s); byName.put(s, id); px[id] = p; } }
        catch (Exception ignored) {}
      }
      version++;
    }
  }
  public static void reopen() { Path d; synchronized (LOCK) { d = file == null ? null : file.getParent(); } open(d); }

  /** Daftarkan tekstur (mis. "minecraft:block/stone"). Return id 1..255, atau 0 bila gagal / atlas penuh. Aman dipanggil dari worker. */
  public static int register(String name) {
    synchronized (LOCK) {
      Integer i = byName.get(name); if (i != null) return i;
      if (names.size() >= MAX) return 0;
      int[] p = load(name); if (p == null) return 0;
      int id = names.size(); names.add(name); byName.put(name, id); px[id] = p; version++; persist(); return id;
    }
  }
  private static void persist() { if (file == null) return; try { Files.createDirectories(file.getParent()); Files.write(file, names.subList(1, names.size())); } catch (Exception ignored) {} }

  private static int[] load(String name) {
    try {
      Identifier id = Identifier.of(name); Identifier tx = Identifier.of(id.getNamespace(), "textures/" + id.getPath() + ".png");
      Optional<Resource> res = MinecraftClient.getInstance().getResourceManager().getResource(tx); if (res.isEmpty()) return null;
      BufferedImage img; try (InputStream in = res.get().getInputStream()) { img = ImageIO.read(in); } if (img == null) return null;
      int w = img.getWidth(), h = Math.min(img.getHeight(), w);   // strip animasi: frame pertama
      int[] rr = new int[SIZE * SIZE], gg = new int[SIZE * SIZE], bb = new int[SIZE * SIZE]; boolean[] ok = new boolean[SIZE * SIZE]; long sr = 0, sg = 0, sb = 0, sn = 0;
      for (int ty = 0; ty < SIZE; ty++) for (int tx2 = 0; tx2 < SIZE; tx2++) {
        int x0 = tx2 * w / SIZE, x1 = Math.max(x0 + 1, (tx2 + 1) * w / SIZE), y0 = ty * h / SIZE, y1 = Math.max(y0 + 1, (ty + 1) * h / SIZE);
        long r = 0, g = 0, b = 0, n = 0, tot = 0;
        for (int y = y0; y < y1 && y < h; y++) for (int x = x0; x < x1 && x < w; x++) { int p = img.getRGB(x, y); tot++; if ((p >>> 24) < 128) continue; r += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255; n++; }
        int i = ty * SIZE + tx2;
        if (n > 0 && n * 2 >= tot) { rr[i] = (int) (r / n); gg[i] = (int) (g / n); bb[i] = (int) (b / n); ok[i] = true; sr += rr[i]; sg += gg[i]; sb += bb[i]; sn++; }
      }
      int fr = sn == 0 ? 128 : (int) (sr / sn), fg = sn == 0 ? 128 : (int) (sg / sn), fb = sn == 0 ? 128 : (int) (sb / sn);   // piksel transparan (daun) diisi warna rata-rata
      int[] out = new int[SIZE * SIZE];
      for (int i = 0; i < out.length; i++) out[i] = 0xFF000000 | (ok[i] ? rr[i] : fr) << 16 | (ok[i] ? gg[i] : fg) << 8 | (ok[i] ? bb[i] : fb);
      return out;
    } catch (Throwable t) { return null; }
  }

  /** Thread render: pasang atlas ke texture unit [unit] (upload ulang bila ada tile baru). */
  public static void bind(int unit) {
    int pu = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
    GL13.glActiveTexture(GL13.GL_TEXTURE0 + unit);
    if (tex == 0) {
      tex = GL11.glGenTextures(); GL11.glBindTexture(GL30.GL_TEXTURE_2D_ARRAY, tex);
      GL11.glTexParameteri(GL30.GL_TEXTURE_2D_ARRAY, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST_MIPMAP_LINEAR); GL11.glTexParameteri(GL30.GL_TEXTURE_2D_ARRAY, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
      GL11.glTexParameteri(GL30.GL_TEXTURE_2D_ARRAY, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE); GL11.glTexParameteri(GL30.GL_TEXTURE_2D_ARRAY, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
      uploaded = 0;
    } else GL11.glBindTexture(GL30.GL_TEXTURE_2D_ARRAY, tex);
    if (uploaded != version) upload();
    GL13.glActiveTexture(pu);
  }
  private static void upload() {
    ByteBuffer b = BufferUtils.createByteBuffer(MAX * SIZE * SIZE * 4); int v;
    synchronized (LOCK) {
      v = version;
      for (int l = 0; l < MAX; l++) { int[] p = px[l]; for (int i = 0; i < SIZE * SIZE; i++) { int c = p == null ? 0 : p[i]; b.put((byte) (c >> 16)).put((byte) (c >> 8)).put((byte) c).put((byte) (p == null ? 0 : 255)); } }
    }
    b.flip();
    GL12.glTexImage3D(GL30.GL_TEXTURE_2D_ARRAY, 0, GL11.GL_RGBA8, SIZE, SIZE, MAX, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, b);
    GL30.glGenerateMipmap(GL30.GL_TEXTURE_2D_ARRAY); uploaded = v;
  }
  public static int count() { synchronized (LOCK) { return names.size() - 1; } }
}
