package com.voltrace.client;
import com.voltrace.client.core.LodManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import com.voltrace.client.config.VolConfig;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
public class VolTraceClient implements ClientModInitializer {
  public static final String MOD_ID = "voltrace";
  public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
  @Override public void onInitializeClient() {
    VolConfig.load();
    ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> LodManager.onChunk(chunk));
    ClientTickEvents.END_CLIENT_TICK.register(LodManager::tick);
    // LOD digambar di BEFORE_TRANSLUCENT (setelah terrain solid + entitas), hanya di piksel kosong. Dengan shader pack, hook pasca-Iris (mixin) yang menggambar.
    WorldRenderEvents.BEFORE_TRANSLUCENT.register(ctx -> LodManager.renderLegacy());
    ClientLifecycleEvents.CLIENT_STOPPING.register(c -> LodManager.shutdown());
    ClientCommandRegistrationCallback.EVENT.register((d, r) -> VolCommands.register(d));
    LOGGER.info("VolTrace siap (LOD {} chunk, bayangan {} chunk)", VolConfig.renderChunks, VolConfig.shadowChunks);
  }
}
