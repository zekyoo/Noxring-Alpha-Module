package com.terraformersmc.modmenu.api;
import net.minecraft.client.gui.screen.Screen;
/** STUB kompilasi (dikeluarkan dari jar). */
@FunctionalInterface public interface ConfigScreenFactory<S extends Screen> { S create(Screen parent); }
