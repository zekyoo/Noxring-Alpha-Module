package com.terraformersmc.modmenu.api;
/** STUB kompilasi (dikeluarkan dari jar). */
public interface ModMenuApi { default ConfigScreenFactory<?> getModConfigScreenFactory() { return parent -> null; } }
