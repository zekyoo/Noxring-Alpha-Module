#version 150
// VolTrace LOD fragment shader: tekstur blok vanilla (atlas array, mipmap), cahaya matahari terarah, bayangan PCF 3x3, kabut.
in vec3 vRgb; in vec3 vW; in vec2 vUV; in vec3 vLoc; in float vDist;
flat in int vFace; flat in float vLayer; flat in float vTint;
uniform vec3 uFogColor; uniform vec2 uFogRange; uniform float uLight; uniform vec3 uSun;
uniform vec4 uOpt;      // x=tekstur y=cahaya matahari z=bayangan w=kabut
uniform vec4 uShadowP;  // x=ukuran map, y=ukuran texel (blok), z=rentang depth (blok), w=kekuatan
uniform mat4 uLightMvp;
uniform sampler2DArray uAtlas; uniform sampler2DShadow uShadow;
out vec4 o;
const vec3 NR[6] = vec3[6](vec3(-1,0,0), vec3(1,0,0), vec3(0,-1,0), vec3(0,1,0), vec3(0,0,-1), vec3(0,0,1));
const float SH[6] = float[6](0.75, 0.75, 0.5, 1.0, 0.85, 0.85);
float h3(vec3 p) { p = fract(p * vec3(.1031, .1030, .0973)); p += dot(p, p.yxz + 33.33); return fract((p.x + p.y) * p.z); }
void main() {
  vec2 gx = dFdx(vUV), gy = dFdy(vUV);   // turunan dihitung di luar percabangan
  vec3 n = NR[vFace]; vec3 c;
  if (uOpt.x > 0.5 && vLayer > 0.0) {
    vec3 tc = textureGrad(uAtlas, vec3(fract(vUV), vLayer), gx, gy).rgb;
    vec3 av = textureLod(uAtlas, vec3(0.5, 0.5, vLayer), 4.0).rgb;   // mip 1x1 = warna rata-rata tile
    c = tc * (vTint > 0.5 ? clamp(vRgb / max(av, vec3(0.04)), 0.0, 3.0) : vec3(1.0));
  } else {
    float k = 1.0 - smoothstep(48.0, 224.0, vDist);
    c = vRgb * (1.0 + (h3(floor(vLoc)) - 0.5) * 0.16 * k + (h3(floor(vLoc * 4.0) + 7.0) - 0.5) * 0.07 * k);
    vec3 fr = abs(fract(vLoc) - 0.5); float e = max(fr.x, max(fr.y, fr.z)); c *= 1.0 - 0.10 * k * smoothstep(0.40, 0.5, e);
  }
  float diff = max(dot(n, uSun), 0.0);
  float shade = (uOpt.y > 0.5) ? (0.55 + 0.45 * diff) : SH[vFace];
  float sh = 1.0;
  if (uOpt.z > 0.5 && diff > 0.0) {
    vec4 lp = uLightMvp * vec4(vW + n * uShadowP.y * 1.5, 1.0); vec3 pc = lp.xyz * 0.5 + 0.5;
    if (pc.x > 0.0 && pc.x < 1.0 && pc.y > 0.0 && pc.y < 1.0 && pc.z < 1.0) {
      float ts = 1.0 / uShadowP.x; float bias = (uShadowP.y * 1.2) / uShadowP.z; float s = 0.0;
      for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) s += textureLod(uShadow, vec3(pc.xy + vec2(float(i), float(j)) * ts, pc.z - bias), 0.0);
      sh = s / 9.0; float e2 = max(abs(lp.x), abs(lp.y)); sh = mix(sh, 1.0, smoothstep(0.85, 1.0, e2));
    }
    shade = 0.55 + 0.45 * diff * mix(1.0 - uShadowP.w, 1.0, sh);
  }
  float f = (uOpt.w > 0.5) ? clamp((vDist - uFogRange.x) / max(uFogRange.y - uFogRange.x, 1.0), 0.0, 1.0) : 0.0;
  o = vec4(mix(c * shade * uLight, uFogColor, f), 1.0);
}
