#version 150
// VolTrace LOD vertex shader.
// aPos = x | y<<6 | z<<12 | face<<18 | tileSisi<<21 | flag<<29 ; aCol = rgb | tileAtas<<24
in uint aPos;
in uint aCol;
//@SEC@
uniform mat4 uMvp;
out vec3 vRgb; out vec3 vW; out vec2 vUV; out vec3 vLoc; out float vDist;
flat out int vFace; flat out float vLayer; flat out float vTint;
const vec3 NR[6] = vec3[6](vec3(-1,0,0), vec3(1,0,0), vec3(0,-1,0), vec3(0,1,0), vec3(0,0,-1), vec3(0,0,1));
void main() {
  vec3 l = vec3(float(aPos & 63u), float((aPos >> 6) & 63u), float((aPos >> 12) & 63u));
  int f = int((aPos >> 18) & 7u);
  vec3 w = aSec.xyz + l * aSec.w;
  gl_Position = uMvp * vec4(w, 1.0);
  vW = w; vDist = length(w); vLoc = l - 0.5 * NR[f]; vFace = f;
  vRgb = vec3(float((aCol >> 16) & 255u), float((aCol >> 8) & 255u), float(aCol & 255u)) / 255.0;
  uint top = (aCol >> 24) & 255u; uint side = (aPos >> 21) & 255u; uint fl = (aPos >> 29) & 3u; bool isTop = (f == 3);
  float layer = float(isTop ? top : side);
  vLayer = layer > 0.5 ? layer : -1.0;
  vTint = ((isTop ? (fl & 1u) : ((fl >> 1) & 1u)) == 1u) ? 1.0 : 0.0;
  vUV = (f < 2) ? vec2(l.z, -l.y) : ((f < 4) ? vec2(l.x, l.z) : vec2(l.x, -l.y));
}
