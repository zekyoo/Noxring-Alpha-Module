# VolTrace

Mod LOD (render chunk jauh) untuk Fabric 1.21.11. Struktur dibuat mengikuti Voxy (`client` / `common` / `commonImpl`, dua mixin config, shader sebagai resource).

```
src/main/java/com/voltrace/
  client/
    VolTraceClient.java            entrypoint client
    VolCommands.java               /voltrace (alias /vt)
    config/  VolConfig, VolSettingsScreen, ModMenuIntegration
    compat/  GpuInfo               deteksi GPU/driver (Android: ANGLE, Zink, GL4ES, MobileGlues, Adreno, Mali ...)
    iris/    IrisCompat
    core/    LodManager, ChunkIngest, LodGenerator (chunk asli), TerrainSynth (terrain jauh dari noise dunia)
      model/      LodColors, TileAtlas (atlas tekstur blok vanilla)
      rendering/  Backend Indirect (GL4.3) / Classic (GL3.2 & GLES3) / CPU, LodTarget, ShadowMap, GlSnapshot, Shaders
    mixin/   iris/MixinIrisRenderingPipeline, minecraft/MixinScreen (tombol di Options, Video Settings, Sodium)
  common/
    world/ LodOctree, Section, Palette      voxelization/ Mesher
  commonImpl/  VolTraceCommon
src/main/resources/
  fabric.mod.json  client.voltrace.mixins.json  common.voltrace.mixins.json
  assets/voltrace/  icon.png  shaders/{lod,post}/*.vert|frag
```

## Cara kerja render
LOD digambar ke FBO sendiri lalu dikomposit ke framebuffer akhir **hanya di piksel yang belum digambar apa pun** (depth scene == nilai clear).
Terrain, entity, block entity, player, dan translucent vanilla tidak pernah tertimpa, dan depth scene tidak diubah.
- Tanpa shader: komposit di event `BEFORE_TRANSLUCENT` dengan tes depth hardware.
- Dengan Iris: depth scene disalin di `BEFORE_TRANSLUCENT`, LOD digambar setelah `IrisRenderingPipeline.finalizeLevelRendering`.

## Default
Jarak LOD 64 chunk, radius bayangan 64 chunk. Config: `config/voltrace.properties`.

## Build
`./gradlew build` -> `build/libs/voltrace-1.2.0-alpha-1.21.11.jar`
