package com.noxring;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*; import java.nio.file.*; import java.util.Properties;
public final class LodConfig {
  public static final int MAX_CHUNKS = 8192;
  public static volatile boolean enabled = true;
  public static volatile int renderChunks = 512;
  public static volatile String backend = "auto";       // auto | indirect | classic | cpu
  public static volatile boolean generate = true;       // singleplayer: buat LOD dari seed
  public static volatile int genChunks = 128;           // radius generator (chunk), 0 = mati
  public static volatile int genPerTick = 1;
  public static int memoryMb = 512;
  public static int buildThreads = Math.max(1, Runtime.getRuntime().availableProcessors() / 2);
  public static int setChunks(int c) { return renderChunks = Math.max(2, Math.min(MAX_CHUNKS, c)); }
  private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("noxring.properties"); }
  public static void load() {
    Properties p = new Properties();
    try (InputStream in = Files.newInputStream(file())) { p.load(in); } catch (IOException e) { return; }
    try { enabled = Boolean.parseBoolean(p.getProperty("enabled", "true")); setChunks(Integer.parseInt(p.getProperty("renderChunks", "512")));
      backend = p.getProperty("backend", "auto"); generate = Boolean.parseBoolean(p.getProperty("generate", "true"));
      genChunks = Integer.parseInt(p.getProperty("genChunks", "128")); genPerTick = Integer.parseInt(p.getProperty("genPerTick", "1")); memoryMb = Integer.parseInt(p.getProperty("memoryMb", "512"));
      buildThreads = Integer.parseInt(p.getProperty("buildThreads", String.valueOf(buildThreads))); } catch (NumberFormatException ignored) {}
  }
  public static void save() {
    Properties p = new Properties(); p.setProperty("enabled", "" + enabled); p.setProperty("renderChunks", "" + renderChunks); p.setProperty("backend", backend);
    p.setProperty("generate", "" + generate); p.setProperty("genChunks", "" + genChunks); p.setProperty("genPerTick", "" + genPerTick);
    p.setProperty("memoryMb", "" + memoryMb); p.setProperty("buildThreads", "" + buildThreads);
    try (OutputStream o = Files.newOutputStream(file())) { p.store(o, "NoxRing"); } catch (IOException ignored) {}
  }
}
