package com.noxring.backend;
import org.lwjgl.opengl.*;
/** Simpan & pulihkan state GL yang kita sentuh, supaya cache state internal Minecraft 1.21.11 tidak rusak. */
public final class GlSnapshot {
  private final boolean depth, cull, blend, scissor, depthMask; private final int depthFunc, drawFbo, readFbo, prog, vao, abuf, indirect, unit, t0, t1; private final float[] cc = new float[4];
  public GlSnapshot() {
    depth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST); cull = GL11.glIsEnabled(GL11.GL_CULL_FACE); blend = GL11.glIsEnabled(GL11.GL_BLEND); scissor = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
    depthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK); depthFunc = GL11.glGetInteger(GL11.GL_DEPTH_FUNC);
    drawFbo = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING); readFbo = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
    prog = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM); vao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING); abuf = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
    indirect = GL11.glGetInteger(GL40.GL_DRAW_INDIRECT_BUFFER_BINDING); GL11.glGetFloatv(GL11.GL_COLOR_CLEAR_VALUE, cc);
    unit = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
    GL13.glActiveTexture(GL13.GL_TEXTURE0); t0 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
    GL13.glActiveTexture(GL13.GL_TEXTURE1); t1 = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
    GL13.glActiveTexture(unit);
  }
  public int drawFbo() { return drawFbo; }
  private static void set(int cap, boolean on) { if (on) GL11.glEnable(cap); else GL11.glDisable(cap); }
  public void restore() {
    GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, drawFbo); GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, readFbo);
    set(GL11.GL_DEPTH_TEST, depth); set(GL11.GL_CULL_FACE, cull); set(GL11.GL_BLEND, blend); set(GL11.GL_SCISSOR_TEST, scissor);
    GL11.glDepthMask(depthMask); GL11.glDepthFunc(depthFunc); GL11.glClearColor(cc[0], cc[1], cc[2], cc[3]);
    GL13.glActiveTexture(GL13.GL_TEXTURE0); GL11.glBindTexture(GL11.GL_TEXTURE_2D, t0);
    GL13.glActiveTexture(GL13.GL_TEXTURE1); GL11.glBindTexture(GL11.GL_TEXTURE_2D, t1);
    GL13.glActiveTexture(unit);
    GL30.glBindVertexArray(vao); GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, abuf); GL15.glBindBuffer(GL40.GL_DRAW_INDIRECT_BUFFER, indirect); GL20.glUseProgram(prog);
  }
}
