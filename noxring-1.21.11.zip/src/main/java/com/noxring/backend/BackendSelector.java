package com.noxring.backend;
import com.noxring.LodConfig; import org.lwjgl.opengl.*;
/** Otomatis: GL4.3+ -> Indirect (gaya Voxy); selain itu Classic (GL3.2, syarat minimum Minecraft sendiri). CPU hanya cadangan/manual. */
public final class BackendSelector {
  public static RenderBackend select() {
    String p = LodConfig.backend.toLowerCase(); GLCapabilities c = GL.getCapabilities();
    return switch (p) { case "cpu" -> new CpuBackend(); case "classic" -> new ClassicBackend();
      case "indirect" -> c.OpenGL43 ? new IndirectBackend() : new ClassicBackend();
      default -> c.OpenGL43 ? new IndirectBackend() : new ClassicBackend(); };
  }
}
