package com.noxring.backend;
import com.noxring.core.LodOctree; import com.noxring.core.LodOctree.*;
import org.joml.Matrix4f; import org.lwjgl.opengl.*; import java.util.List;
/** Cadangan tanpa fitur GPU modern: heightfield ray-march di CPU -> tekstur kecil -> 1 segitiga layar penuh. Lebih lambat, tapi jalan di mana saja. */
public final class CpuBackend implements RenderBackend {
  private static final int W = 192, H = 108;
  private final int[] px = new int[W * H]; private int tex, prog, vao, frame;
  public String name() { return "CPU (software raymarch)"; } public boolean wantsMeshes() { return false; }
  public void init() {
    prog = Shaders.program("#version 150\nout vec2 uv; void main(){ vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2)); uv=p; gl_Position=vec4(p*2.0-1.0,0.0,1.0); }",
      "#version 150\nin vec2 uv; uniform sampler2D uTex; out vec4 o; void main(){ o=texture(uTex,uv); }");
    vao = GL30.glGenVertexArrays(); tex = GL11.glGenTextures();
    int prev = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D); GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
    GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, W, H, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, 0L);
    GL11.glBindTexture(GL11.GL_TEXTURE_2D, prev);
  }
  public void upload(Key k, int[] m) {} public void remove(Key k) {} public void clear() {}
  public void draw(Frame f, List<Key> keys) {
    int prevTex = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D), prevUnit = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
    GL13.glActiveTexture(GL13.GL_TEXTURE0); GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex);
    if (frame++ % 4 == 0) { render(f); GL11.glTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, W, H, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, px); }
    GL11.glDisable(GL11.GL_DEPTH_TEST); GL11.glDisable(GL11.GL_BLEND);
    GL20.glUseProgram(prog); GL20.glUniform1i(GL20.glGetUniformLocation(prog, "uTex"), 0); GL30.glBindVertexArray(vao); GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
    GL11.glEnable(GL11.GL_DEPTH_TEST);
    GL11.glBindTexture(GL11.GL_TEXTURE_2D, prevTex); GL13.glActiveTexture(prevUnit);
  }
  private void render(Frame f) {
    Matrix4f v = f.view(); double rx = v.m00(), ry = v.m10(), rz = v.m20(), ux = v.m01(), uy = v.m11(), uz = v.m21(), fx = -v.m02(), fy = -v.m12(), fz = -v.m22();
    LodOctree t = f.tree(); double t0 = Math.max(16, f.vanillaB() * 0.9), maxB = f.maxB();
    CK lastK = null; Column lastC = null;
    for (int j = 0; j < H; j++) for (int i = 0; i < W; i++) {
      double nx = ((i + .5) / W * 2 - 1) * f.tanX(), ny = ((j + .5) / H * 2 - 1) * f.tanY();
      double dx = fx + rx * nx + ux * ny, dy = fy + ry * nx + uy * ny, dz = fz + rz * nx + uz * ny, len = Math.sqrt(dx * dx + dy * dy + dz * dz); dx /= len; dy /= len; dz /= len;
      int out = 0;
      for (double d = t0; d < maxB; d *= 1.03) {
        double y = f.cy() + dy * d; if (dy > 0 && y > 400) break;
        int lv = Math.min(LodOctree.MAX_LEVEL, Math.max(0, (int) Math.floor(Math.log(d / 384.0) / Math.log(2)))), cell = 1 << lv;
        int cx = Math.floorDiv((int) Math.floor(f.cx() + dx * d), cell), cz = Math.floorDiv((int) Math.floor(f.cz() + dz * d), cell);
        CK ck = new CK(lv, Math.floorDiv(cx, 32), Math.floorDiv(cz, 32));
        if (!ck.equals(lastK)) { lastK = ck; lastC = t.column(ck, false); if (lastC != null) t.ensureTop(lastC); }
        if (lastC == null || lastC.topY == null) continue;
        int idx = Math.floorMod(cz, 32) * 32 + Math.floorMod(cx, 32), ty = lastC.topY[idx];
        if (ty != Integer.MIN_VALUE && y <= (double) (ty + 1) * cell) {
          int rgb = t.palette.rgb(lastC.topC[idx]); float fg = (float) Math.min(1, Math.max(0, (d - f.fogStart()) / Math.max(1, f.fogEnd() - f.fogStart())));
          int r = (int) ((((rgb >> 16) & 255) * f.light()) * (1 - fg) + f.fog()[0] * 255 * fg), g = (int) ((((rgb >> 8) & 255) * f.light()) * (1 - fg) + f.fog()[1] * 255 * fg), b = (int) (((rgb & 255) * f.light()) * (1 - fg) + f.fog()[2] * 255 * fg);
          out = 0xFF000000 | Math.min(255, b) << 16 | Math.min(255, g) << 8 | Math.min(255, r); break;
        }
      }
      px[(H - 1 - j) * W + i] = out;
    }
  }
  public void close() { if (prog != 0) { GL20.glDeleteProgram(prog); GL11.glDeleteTextures(tex); GL30.glDeleteVertexArrays(vao); } }
}
