package com.noxring.backend;
import org.lwjgl.opengl.*;
final class Shaders {
  /** perInstance=true: aSec dari atribut instance (MDI, GL 4.3). false: uniform per section (GL 3.2). */
  static String vs(boolean perInstance) {
    return "#version 150\nin uint aPos; in uint aCol;\n" + (perInstance ? "in vec4 aSec;\n" : "uniform vec4 aSec;\n") +
      "uniform mat4 uMvp; out vec3 vCol; out vec3 vLoc; out float vDist;\n" +
      "const float SH[6]=float[6](0.75,0.75,0.5,1.0,0.85,0.85);\n" +
      "const vec3 NR[6]=vec3[6](vec3(-1,0,0),vec3(1,0,0),vec3(0,-1,0),vec3(0,1,0),vec3(0,0,-1),vec3(0,0,1));\n" +
      "void main(){ vec3 l=vec3(float(aPos&63u),float((aPos>>6)&63u),float((aPos>>12)&63u)); int f=int((aPos>>18)&7u);\n" +
      " vec3 w=aSec.xyz+l*aSec.w; gl_Position=uMvp*vec4(w,1.0); vDist=length(w); vLoc=l-0.5*NR[f];\n" +
      " vCol=vec3(float((aCol>>16)&255u),float((aCol>>8)&255u),float(aCol&255u))/255.0*SH[f]; }";
  }
  /** Fragment: variasi per blok + piksel 4x4 per blok + garis tepi blok, memudar dengan jarak (detail ala tekstur dekat kamera). */
  static final String FS = "#version 150\nin vec3 vCol; in vec3 vLoc; in float vDist; uniform vec3 uFogColor; uniform vec2 uFogRange; uniform float uLight; out vec4 o;\n" +
    "float h3(vec3 p){ p=fract(p*vec3(.1031,.1030,.0973)); p+=dot(p,p.yxz+33.33); return fract((p.x+p.y)*p.z); }\n" +
    "void main(){ float k=1.0-smoothstep(48.0,224.0,vDist);\n" +
    " vec3 c=vCol*(1.0+(h3(floor(vLoc))-0.5)*0.16*k+(h3(floor(vLoc*4.0)+7.0)-0.5)*0.07*k);\n" +
    " vec3 fr=abs(fract(vLoc)-0.5); float e=max(fr.x,max(fr.y,fr.z)); c*=1.0-0.10*k*smoothstep(0.40,0.5,e);\n" +
    " float f=clamp((vDist-uFogRange.x)/max(uFogRange.y-uFogRange.x,1.0),0.0,1.0); o=vec4(mix(c*uLight,uFogColor,f),1.0); }";
  static int program(String vs, String fs, String... attribs) {
    int v = shader(GL20.GL_VERTEX_SHADER, vs), f = shader(GL20.GL_FRAGMENT_SHADER, fs), p = GL20.glCreateProgram();
    GL20.glAttachShader(p, v); GL20.glAttachShader(p, f);
    for (int i = 0; i < attribs.length; i++) GL20.glBindAttribLocation(p, i, attribs[i]);
    GL20.glLinkProgram(p);
    if (GL20.glGetProgrami(p, GL20.GL_LINK_STATUS) == 0) throw new IllegalStateException("link: " + GL20.glGetProgramInfoLog(p));
    GL20.glDeleteShader(v); GL20.glDeleteShader(f); return p;
  }
  static int shader(int type, String src) {
    int s = GL20.glCreateShader(type); GL20.glShaderSource(s, src); GL20.glCompileShader(s);
    if (GL20.glGetShaderi(s, GL20.GL_COMPILE_STATUS) == 0) throw new IllegalStateException("shader: " + GL20.glGetShaderInfoLog(s));
    return s;
  }
  static void uniforms(int p, Frame f) {
    GL20.glUniformMatrix4fv(GL20.glGetUniformLocation(p, "uMvp"), false, f.mvp());
    GL20.glUniform3f(GL20.glGetUniformLocation(p, "uFogColor"), f.fog()[0], f.fog()[1], f.fog()[2]);
    GL20.glUniform2f(GL20.glGetUniformLocation(p, "uFogRange"), f.fogStart(), f.fogEnd());
    GL20.glUniform1f(GL20.glGetUniformLocation(p, "uLight"), f.light());
  }
}
