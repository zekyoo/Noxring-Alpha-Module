package com.noxring;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;
public class NoxRing implements ClientModInitializer {
  public static final String MOD_ID = "noxring";
  public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
  @Override public void onInitializeClient() {
    LodConfig.load();
    ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> LodManager.onChunk(chunk));
    ClientTickEvents.END_CLIENT_TICK.register(LodManager::tick);
    // LOD digambar setelah terrain solid + entitas, sebelum translucent. Tidak memakai objek context agar tahan perubahan API.
    WorldRenderEvents.BEFORE_TRANSLUCENT.register(ctx -> LodManager.render());
    ClientLifecycleEvents.CLIENT_STOPPING.register(c -> LodManager.shutdown());
    ClientCommandRegistrationCallback.EVENT.register((d, r) -> NoxCommands.register(d));
    LOGGER.info("NoxRing LOD siap (maks {} chunk)", LodConfig.MAX_CHUNKS);
  }
}
