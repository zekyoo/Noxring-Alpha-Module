package com.noxring;
import com.noxring.core.*;
import net.minecraft.block.BlockState; import net.minecraft.util.math.ChunkPos; import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk; import net.minecraft.world.chunk.ChunkSection;
import java.util.*;
/** Salin satu chunk (client WorldChunk ATAU ProtoChunk hasil generator) ke LOD level 0, lalu rambatkan ke semua level. Jalan di worker thread. */
final class ChunkIngest {
  private record BK(LodColors.Info in, Biome b) {}
  static void run(LodOctree tree, Chunk chunk) {
    ChunkPos cp = chunk.getPos(); int bx = cp.getStartX(), bz = cp.getStartZ();
    int sx = Math.floorDiv(bx, 32), sz = Math.floorDiv(bz, 32), lx = Math.floorMod(bx, 32), lz = Math.floorMod(bz, 32);
    ChunkSection[] arr = chunk.getSectionArray(); Set<LodOctree.Key> touched = new HashSet<>();
    IdentityHashMap<LodColors.Info, Short> plain = new IdentityHashMap<>(); HashMap<BK, Short> tinted = new HashMap<>();
    for (int i = 0; i < arr.length; i++) {
      ChunkSection cs = arr[i]; if (cs == null) continue;
      int y0 = chunk.sectionIndexToCoord(i) * 16, sy = Math.floorDiv(y0, 32), ly = Math.floorMod(y0, 32);
      LodOctree.Key key = new LodOctree.Key(0, sx, sy, sz); boolean empty = cs.isEmpty();
      Section s = empty ? tree.get(key) : tree.getOrCreate(key); if (s == null) continue;
      for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
        short id = 0;
        if (!empty) {
          LodColors.Info in = LodColors.info(cs.getBlockState(x, y, z));
          if (in != LodColors.NONE) {
            if (!in.tinted()) id = plain.computeIfAbsent(in, k -> tree.palette.idFor(k.rgb()));
            else { Biome b = chunk.getBiomeForNoiseGen((bx + x) >> 2, (y0 + y) >> 2, (bz + z) >> 2).value();
              id = tinted.computeIfAbsent(new BK(in, b), k -> tree.palette.idFor(LodColors.mul(k.in().rgb(), LodColors.tint(k.in(), k.b(), bx + 8, bz + 8)))); }
          }
        }
        s.set(lx + x, ly + y, lz + z, id);
      }
      s.compact(); s.version++; tree.touch(key); touched.add(key);
    }
    for (LodOctree.Key k : touched) tree.propagate(k);
    tree.markChunk(cp.x, cp.z);
  }
}
