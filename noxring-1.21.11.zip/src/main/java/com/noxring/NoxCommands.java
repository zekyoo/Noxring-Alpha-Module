package com.noxring;
import com.mojang.brigadier.CommandDispatcher; import com.mojang.brigadier.arguments.*;
import net.fabricmc.fabric.api.client.command.v2.*; import net.minecraft.text.Text;
final class NoxCommands {
  static void register(CommandDispatcher<FabricClientCommandSource> d) {
    d.register(ClientCommandManager.literal("noxring")
      .then(ClientCommandManager.literal("distance").then(ClientCommandManager.argument("chunks", IntegerArgumentType.integer(2, LodConfig.MAX_CHUNKS)).executes(c -> {
        int v = LodConfig.setChunks(IntegerArgumentType.getInteger(c, "chunks")); LodConfig.save();
        c.getSource().sendFeedback(Text.literal("NoxRing jarak = " + v + " chunk")); return 1; })))
      .then(ClientCommandManager.literal("backend").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
        String n = StringArgumentType.getString(c, "name"); LodManager.setBackend(n); LodConfig.save();
        c.getSource().sendFeedback(Text.literal("NoxRing backend = " + n + " (auto|indirect|classic|cpu)")); return 1; })))
      .then(ClientCommandManager.literal("gen").then(ClientCommandManager.argument("radius", IntegerArgumentType.integer(0, LodConfig.MAX_CHUNKS)).executes(c -> {
        LodConfig.genChunks = IntegerArgumentType.getInteger(c, "radius"); LodConfig.save();
        c.getSource().sendFeedback(Text.literal("NoxRing generator radius = " + LodConfig.genChunks + " chunk (0 = mati, hanya singleplayer)")); return 1; })))
      .then(ClientCommandManager.literal("reload").executes(c -> { LodColors.reload(net.minecraft.client.MinecraftClient.getInstance());
        c.getSource().sendFeedback(Text.literal("NoxRing warna blok dimuat ulang dari resource pack")); return 1; }))
      .then(ClientCommandManager.literal("toggle").executes(c -> { LodConfig.enabled = !LodConfig.enabled; LodConfig.save();
        c.getSource().sendFeedback(Text.literal("NoxRing " + (LodConfig.enabled ? "aktif" : "mati"))); return 1; }))
      .then(ClientCommandManager.literal("status").executes(c -> { c.getSource().sendFeedback(Text.literal(LodManager.status())); return 1; })));
  }
}
