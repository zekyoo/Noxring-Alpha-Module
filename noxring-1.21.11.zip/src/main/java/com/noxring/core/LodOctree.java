package com.noxring.core;
import java.io.*; import java.nio.file.*; import java.util.*; import java.util.concurrent.*; import java.util.zip.*;
/**
 * Penyimpanan LOD voxel sparse. Level n: 1 sel = 2^n blok; 1 section = 32 sel. Level 0..12 menutup > 8192 chunk.
 * Section dikelompokkan per kolom (level,sx,sz). Kolom di-cache di RAM (LRU) dan disimpan ke disk (deflate).
 */
public final class LodOctree {
  public static final int MAX_LEVEL = 12, S = Section.N;
  public record CK(int level, int sx, int sz) {}
  public record Key(int level, int sx, int sy, int sz) { public CK ck() { return new CK(level, sx, sz); } }
  public static final class Column {
    public final ConcurrentHashMap<Integer, Section> secs = new ConcurrentHashMap<>();
    public volatile long last = System.nanoTime(); public volatile boolean dirty; public volatile int ver;
    public volatile int topVer = -1; public volatile int[] topY; public volatile short[] topC;
  }
  private final ConcurrentHashMap<CK, Column> cols = new ConcurrentHashMap<>();
  private final Set<CK> known = ConcurrentHashMap.newKeySet();
  public final Palette palette = new Palette();
  private final Path dir;
  private final Set<Long> chunks = ConcurrentHashMap.newKeySet(); private volatile boolean chunksDirty;
  public static long cpk(int x, int z) { return ((long) x << 32) | (z & 0xFFFFFFFFL); }
  public boolean hasChunk(int x, int z) { return chunks.contains(cpk(x, z)); }
  public void markChunk(int x, int z) { if (chunks.add(cpk(x, z))) chunksDirty = true; }
  public int chunkCount() { return chunks.size(); }
  private void loadChunks() {
    Path f = dir.resolve("chunks.bin"); if (!Files.exists(f)) return;
    try (DataInputStream in = new DataInputStream(new BufferedInputStream(new InflaterInputStream(Files.newInputStream(f))))) {
      int n = in.readInt(); for (int i = 0; i < n; i++) chunks.add(in.readLong());
    } catch (IOException e) { e.printStackTrace(); }
  }
  private void saveChunks() {
    try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new DeflaterOutputStream(Files.newOutputStream(dir.resolve("chunks.bin")))))) {
      Long[] a = chunks.toArray(new Long[0]); o.writeInt(a.length); for (long v : a) o.writeLong(v);
    } catch (IOException e) { e.printStackTrace(); }
  }

  public LodOctree(Path dir) {
    this.dir = dir;
    if (dir == null) return;
    try { Files.createDirectories(dir); palette.load(dir.resolve("palette.bin")); loadChunks(); scan(); } catch (IOException e) { e.printStackTrace(); }
  }
  private void scan() throws IOException {
    for (int l = 0; l <= MAX_LEVEL; l++) {
      Path d = dir.resolve("L" + l); if (!Files.isDirectory(d)) continue;
      try (DirectoryStream<Path> ds = Files.newDirectoryStream(d, "*.lod")) {
        for (Path f : ds) { String n = f.getFileName().toString(); n = n.substring(0, n.length() - 4); int u = n.indexOf('_', 1);
          try { known.add(new CK(l, Integer.parseInt(n.substring(0, u)), Integer.parseInt(n.substring(u + 1)))); } catch (Exception ignored) {} }
      }
    }
  }
  private Path file(CK k) { return dir.resolve("L" + k.level()).resolve(k.sx() + "_" + k.sz() + ".lod"); }

  public Column column(CK k, boolean create) {
    Column c = cols.get(k);
    if (c != null) { c.last = System.nanoTime(); return c; }
    if (!create && !known.contains(k)) return null;
    c = cols.computeIfAbsent(k, kk -> { Column l = known.contains(kk) ? load(kk) : null; return l != null ? l : new Column(); });
    if (create) known.add(k);
    return c;
  }
  public Section get(Key k) { Column c = column(k.ck(), false); return c == null ? null : c.secs.get(k.sy()); }
  public Section getOrCreate(Key k) { return column(k.ck(), true).secs.computeIfAbsent(k.sy(), x -> new Section()); }
  public void touch(Key k) { Column c = column(k.ck(), true); c.dirty = true; c.ver++; }
  public int columnCount() { return cols.size(); }

  /** Isi 1/8 bagian parent dari satu child (solid menang atas udara, prioritas atas). */
  public void downsample(Key child) {
    Section c = get(child); if (c == null) return;
    Key p = new Key(child.level() + 1, Math.floorDiv(child.sx(), 2), Math.floorDiv(child.sy(), 2), Math.floorDiv(child.sz(), 2));
    Section s = c.isEmpty() ? get(p) : getOrCreate(p); if (s == null) return;
    int ox = Math.floorMod(child.sx(), 2) * 16, oy = Math.floorMod(child.sy(), 2) * 16, oz = Math.floorMod(child.sz(), 2) * 16, h = S / 2;
    for (int x = 0; x < h; x++) for (int y = 0; y < h; y++) for (int z = 0; z < h; z++) {
      short best = 0;
      for (int d = 0; d < 8; d++) { short v = c.at(x * 2 + (d & 1), y * 2 + ((d >> 1) & 1), z * 2 + ((d >> 2) & 1)); if (v != 0) best = v; }
      s.set(ox + x, oy + y, oz + z, best);
    }
    s.compact(); s.version++; touch(p);
  }
  /** Rambatkan perubahan level 0 ke semua level di atasnya. */
  public void propagate(Key k) {
    for (int l = k.level(); l < MAX_LEVEL; l++) { downsample(k); k = new Key(l + 1, Math.floorDiv(k.sx(), 2), Math.floorDiv(k.sy(), 2), Math.floorDiv(k.sz(), 2)); }
  }
  /** Peta ketinggian per kolom (untuk backend CPU). */
  public void ensureTop(Column c) {
    if (c.topVer == c.ver && c.topY != null) return;
    int ver = c.ver; int[] ty = new int[1024]; short[] tc = new short[1024]; Arrays.fill(ty, Integer.MIN_VALUE);
    Integer[] sys = c.secs.keySet().toArray(new Integer[0]); Arrays.sort(sys, Collections.reverseOrder());
    for (int sy : sys) { Section s = c.secs.get(sy); if (s == null || s.isEmpty()) continue;
      for (int z = 0; z < S; z++) for (int x = 0; x < S; x++) { int i = z * S + x; if (ty[i] != Integer.MIN_VALUE) continue;
        for (int y = S - 1; y >= 0; y--) { short v = s.at(x, y, z); if (v != 0) { ty[i] = sy * S + y; tc[i] = v; break; } } } }
    c.topC = tc; c.topY = ty; c.topVer = ver;
  }

  // ---- disk ----
  private Column load(CK k) {
    try (DataInputStream in = new DataInputStream(new BufferedInputStream(new InflaterInputStream(Files.newInputStream(file(k)))))) {
      Column c = new Column(); int n = in.readInt();
      for (int i = 0; i < n; i++) { int sy = in.readInt(); Section s = new Section(); s.uniform = in.readShort();
        if (in.readBoolean()) { short[] a = new short[Section.VOL]; for (int j = 0; j < a.length; j++) a[j] = in.readShort(); s.cells = a; }
        c.secs.put(sy, s); }
      return c;
    } catch (IOException e) { return null; }
  }
  private void save(CK k, Column c) {
    if (dir == null) return;
    try { Path f = file(k); Files.createDirectories(f.getParent()); Path tmp = f.resolveSibling(f.getFileName() + ".tmp");
      try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new DeflaterOutputStream(Files.newOutputStream(tmp), new Deflater(1))))) {
        List<Map.Entry<Integer, Section>> es = new ArrayList<>(c.secs.entrySet()); o.writeInt(es.size());
        for (var e : es) { Section s = e.getValue(); o.writeInt(e.getKey()); o.writeShort(s.uniform); short[] a = s.cells; o.writeBoolean(a != null);
          if (a != null) for (short v : a) o.writeShort(v); }
      }
      Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
    } catch (IOException e) { e.printStackTrace(); }
  }
  public void saveDirty() {
    for (var e : cols.entrySet()) { Column c = e.getValue(); if (c.dirty) { c.dirty = false; save(e.getKey(), c); } }
    if (dir != null) { palette.save(dir.resolve("palette.bin")); if (chunksDirty) { chunksDirty = false; saveChunks(); } }
  }
  public void saveAll() { saveDirty(); }
  /** Buang kolom yang lama tidak dipakai bila RAM melebihi budget (disimpan dulu bila berubah). */
  public void evict(long budgetBytes) {
    long sum = 0; for (Column c : cols.values()) for (Section s : c.secs.values()) sum += s.bytes();
    if (sum <= budgetBytes) return;
    List<Map.Entry<CK, Column>> l = new ArrayList<>(cols.entrySet()); l.sort(Comparator.comparingLong(e -> e.getValue().last));
    long now = System.nanoTime();
    for (var e : l) { if (sum <= budgetBytes) break; Column c = e.getValue(); if (now - c.last < 5_000_000_000L) continue;
      if (c.dirty) { c.dirty = false; save(e.getKey(), c); }
      cols.remove(e.getKey()); for (Section s : c.secs.values()) sum -= s.bytes(); }
  }
}
