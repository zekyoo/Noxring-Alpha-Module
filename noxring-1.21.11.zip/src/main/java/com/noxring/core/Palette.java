package com.noxring.core;
import java.io.*; import java.nio.file.*; import java.util.concurrent.ConcurrentHashMap;
public final class Palette {
  private final int[] colors = new int[65536];
  private final ConcurrentHashMap<Integer, Short> ids = new ConcurrentHashMap<>();
  private int next = 1;
  public synchronized short idFor(int rgb) {
    rgb &= 0xFFFFFF; Short s = ids.get(rgb); if (s != null) return s;
    if (next >= 65535) return 1;
    colors[next] = rgb; ids.put(rgb, (short) next); return (short) next++;
  }
  public int rgb(short id) { return colors[id & 0xFFFF]; }
  public synchronized void save(Path p) {
    try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(p)))) {
      o.writeInt(next); for (int i = 1; i < next; i++) o.writeInt(colors[i]);
    } catch (IOException e) { e.printStackTrace(); }
  }
  public synchronized void load(Path p) {
    if (!Files.exists(p)) return;
    try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(p)))) {
      int n = in.readInt(); for (int i = 1; i < n; i++) { colors[i] = in.readInt(); ids.put(colors[i], (short) i); } next = n;
    } catch (IOException e) { e.printStackTrace(); }
  }
}
