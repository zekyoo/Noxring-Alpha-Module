# NoxRing (Fabric 1.21.11)
LOD voxel gaya Voxy + backend berlapis ala Distant Horizons. Jarak sampai 8192 chunk. Hanya client.

## Build
Upload seluruh isi folder ini ke repo GitHub -> tab Actions -> workflow `build` -> unduh artifact `Artifacts` (jar ada di dalamnya).
Atau di PC: `./gradlew build` -> `build/libs/`.

## Perintah (`/noxring ...`)
`distance <2-8192>` · `backend auto|indirect|classic|cpu` · `gen <radius>` · `reload` · `toggle` · `status`

## Cara kerja
- Chunk client + chunk hasil generator (singleplayer) disalin ke octree LOD (level 0..12) dan disimpan di `noxring/<dunia>/`.
- Warna = rata-rata tekstur PNG asli + tint biome. Shader fragment menambah detail piksel dekat kamera.
- Gambar: FBO sendiri -> komposit dengan kedalaman ala vanilla (aman untuk shader pack). Backend: GL4.3 Indirect, GL3.2 Classic, CPU cadangan.
- Multiplayer: LOD hanya dari chunk yang pernah dimuat.
